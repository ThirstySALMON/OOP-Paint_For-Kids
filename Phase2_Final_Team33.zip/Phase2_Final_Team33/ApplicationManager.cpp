#include <cstdlib> // Added to import random function
#include "Figures\CRectangle.h"
#include"Figures\CSquare.h"
#include"Figures\CTriangle.h"
#include"Figures\CHexagon.h"
#include"Figures\CCircle.h"
#include "ApplicationManager.h"                                                         
#include "Actions\AddRectAction.h"
#include "Actions\AddHexAction.h"
#include "Actions\Select.h"                                 
#include "Actions\AddSquareAction.h"
#include "Actions\AddCircAction.h"
#include "Actions\AddTriAction.h"
#include "Actions\ClearAll.h"
#include"Actions\ChangeBorderColor.h"
#include"Actions\ChangeFillColor.h"
#include"Actions\DeleteAction.h"
#include"Actions\Send_2_back.h"
#include "Actions\Bring_2_front.h"
#include"Actions\CutAction.h"
#include"Actions\CopyAction.h"
#include"Actions\PasteAction.h"
#include"Actions\SaveAction.h"
#include"Actions\LoadAction.h"
#include"Actions\Switch2play.h"
#include"Actions\Switch2Draw.h"
#include"Actions\Picktype.h"
#include"Actions\pickcolor.h"
#include"Actions\Picktype_color.h"
#include<iostream>
#include<Windows.h>
#include<mmsystem.h>
#include"fstream"
#pragma comment(lib , "winmm.lib")
//Constructor
ApplicationManager::ApplicationManager()
{
	//Create Input and output
	pOut = new Output;
	pIn = pOut->CreateInput();
	SelectedFig = NULL;
	Clipboard = NULL;
	FigCount = 0;
	Playfigcount = 0;
	crntfill = WHITE;
	crntdraw = BLUE;
	srand(time(0));
	voice_on = true;
	//Create an array of figure pointers and set them to NULL		
	for (int i = 0; i < MaxFigCount; i++) {
		FigList[i] = NULL;
		PlayFigList[i] = NULL;
	}
	
}

//==================================================================================//
//								Actions Related Functions							//
//==================================================================================//
ActionType ApplicationManager::GetUserAction() const
{
	//Ask the input to get the action from the user.
	return pIn->GetUserAction();		
}
////////////////////////////////////////////////////////////////////////////////////
//Creates an action and executes it
void ApplicationManager::ExecuteAction(ActionType ActType) 
{
	Action* pAct = NULL;
	
	//According to Action Type, create the corresponding action object
	switch (ActType)
	{
		case DRAW_RECT:
			pAct = new AddRectAction(this);
			if (voice_on) { PlaySound("AudioFiles/rectangle.wav", NULL, SND_FILENAME | SND_ASYNC); }
			break;
		case DRAW_SQUARE:
			pAct = new AddSquareAction(this);
			if (voice_on) { PlaySound("AudioFiles/square.wav", NULL, SND_FILENAME | SND_ASYNC); }
			break;
		case DRAW_CIRCLE:
			pAct = new AddCircAction(this);
			if (voice_on) { PlaySound("AudioFiles/circle.wav", NULL, SND_FILENAME | SND_ASYNC); }
			break;
		case DRAW_HEXAGON:
			pAct = new AddHexAction(this);
			if (voice_on) { PlaySound("AudioFiles/hexagon.wav", NULL, SND_FILENAME | SND_ASYNC); }
			break;
		case DRAW_TRIANGLE:
			pAct = new AddTriAction(this);
			if (voice_on) { PlaySound("AudioFiles/triangle.wav", NULL, SND_FILENAME | SND_ASYNC); }
			break;
		case SELECT_FIGURE:
			pAct = new SelectAct(this);
			break;
		case CLEAR_ALLF:
			pAct= new ClearAll(this);
			break;
		case CHANGE_B_COLOR:
			pAct = new ChangeBorderColor(this);
			break;
		case CHANGE_F_COLOR:
			pAct = new ChangeFillColor(this);
			break;
		case DELETEF:
			pAct = new DeleteAction(this);
			break;
		case SEND2BACK:
			pAct = new Sendingback(this);
			break;
		case BRING2FRONT:
			pAct = new bringfront(this);
			break;
		case CUTF:
			pAct = new CutAction(this);
			break;
		case COPYF:
			pAct = new CopyAction(this);
			break;
		case PASTEF:
			pAct = new PasteAction(this);
			break;
		case SAVEF:
			pAct = new SaveAction(this);
			break;
		case LOADF:
			pAct = new LoadAction(this);
			break;
		case TO_PLAY:
			pAct = new Switch2Play(this);
			if (voice_on) { PlaySound("AudioFiles/play mode.wav", NULL, SND_FILENAME | SND_ASYNC); }
			break;
		case TO_DRAW:
			pAct = new Switch2Draw(this);
			if (voice_on) { PlaySound("AudioFiles/draw mode.wav", NULL, SND_FILENAME | SND_ASYNC); }

			break;
		case PICKT:
			pAct = new Picktype(this);
			break;
		case PICKC:
			pAct = new Pickcolor(this);
			break;
		case PICKCT:
			pAct = new Pickt_c(this);
			break;
		case VOICE_TOGGLE:
			voice_on = (voice_on) ? false : true;
			if (voice_on) { pOut->PrintMessage("Voice on"); }
			else { pOut->PrintMessage("Voice off"); }
		case EXIT:
			break;
		
		case STATUS:	//a click on the status bar ==> no action
			return;
	}
	
	//Execute the created action
	if(pAct != NULL)
	{
		pAct->Execute();//Execute
		delete pAct;	//You may need to change this line depending to your implementation
		pAct = NULL;
	}
}
//==================================================================================//
//						Figures Management Functions								//
//==================================================================================//
void ApplicationManager::DeleteAll() {
	for (int i = 0; i < FigCount; i++) {
		delete FigList[i]; 
		FigList[i] = NULL;
	}
	SelectedFig = NULL;
	if(Clipboard!=NULL&& !Clipboard->getCut())
		delete Clipboard;
	Clipboard = NULL;
	FigCount = 0;
}
///////////////////////////////////////////////////////////////////////////////////////
void ApplicationManager::AddFigure(CFigure* pFig)          //Add a figure to the list of figures
{                         

	if (FigCount < MaxFigCount)
		pFig->SetID(rand() % 1000);
		FigList[FigCount++] = pFig;

	
}
///////////////////////////////////////////////////////////////////////////////////////
void ApplicationManager::DeleteselectedFigs() {
	int c = getselectedfignumber();
	for (int i = 0; i < c; i++) { // outer for loop to see how many time the operation will be done 
		for (int j = 0;j < FigCount; j++) {   // first inner for loop to search for the selected figs and deleting them
			if (FigList[j]->IsSelected()) {
				delete FigList[j];
				for (int k = j; k < FigCount; k++) { // second inner for loop for rearranging the Figlist array
					FigList[k] = FigList[k + 1];
				}
				FigCount--;
			}

		}
	}
}
////////////////////////////////////////////////////////////////////////////////////
CFigure* ApplicationManager::GetFigure(int x, int y) const
{
	//If a figure is found return a pointer to it.
	//if this point (x,y) does not belong to any figure return NULL
	for (int i = FigCount - 1; i >= 0; i--)
	{
		if (FigList[i]->Search(x, y)) {
			return FigList[i];
		}
	}
	for (int i = 0; i < FigCount; i++) {
		FigList[i]->SetSelected(false);
	}
	return NULL;
}
////////////////////////////////////////////////////////////////////////////////
void ApplicationManager::SetSelectedFig(CFigure*figure) {
	if (getselectedfignumber() == 1) {
		for (int i = 0; i < FigCount; i++) {
			if (FigList[i]->IsSelected() == true) {
				SelectedFig = FigList[i];
				break;
			}
		}
	}
	else if(getselectedfignumber()==0)
		SelectedFig = figure;


}///////////////////////////////////////////////////////////////////////////////
CFigure* ApplicationManager::GetselectedFig() const {
	return SelectedFig;
}
int ApplicationManager::getselectedfigindex() const
{
	if (SelectedFig != NULL) {
		for (int i = 0; i < FigCount; i++) {
			if (SelectedFig == FigList[i])
				return i;
		}
	}
		return -1;
	
}
void ApplicationManager::send2back()
{

	if (getselectedfigindex() != -1) { // safety checking so that no edits occur if no selected figure (see comments for getselectedfigindex)
		int z = getselectedfigindex(); 
		for (int i = z; i > 0; i--) {      //  rearranges array so that the selected figure is at the back and the rest of the elements keep their position relative to the new array  
			FigList[i] = FigList[i - 1]; 
		}
		FigList[0] = SelectedFig;   // put the selected element at the back of the array 

	}
}
//////////////////////////////////////////////////////////////////////////////
void ApplicationManager::bring2front()
{
	if (getselectedfigindex() != -1) { // safety checking so that no edits occur if no selected figure (see comments for getselectedfigindex)
		int z = getselectedfigindex();
		for (int i = z; i <FigCount; i++) {      //  same concept as send2back but the reverse  
			FigList[i] = FigList[i + 1];
		}
		FigList[FigCount-1] = SelectedFig;   // put the selected element at the front of the array 

	}
}
///////////////////////////////////////////////////////////////////////////////
int ApplicationManager::getselectedfignumber() {
	int counter = 0; 
	for (int i = 0; i < FigCount; i++) {
		if (FigList[i]->IsSelected())
			counter++;
	}
	return counter;
}
/////////////////////////////////////////////////////////////////////////////////////
int ApplicationManager::SaveAll(ofstream& save_file) {
	if (FigCount == 0)
		return 1;
	save_file << color2string(crntfill) << " " << color2string(crntdraw) << endl<<FigCount<<endl;
	for (int i = 0; i < FigCount;i++) {
		FigList[i]->Save(save_file);
	}
	
}
/////////////////////////////////////////////////////////////////////////////////////
//==================================================================================//
//							Interface Management Functions							//
//==================================================================================//

//Draw all figures on the user interface
void ApplicationManager::UpdateInterface()
{
	
	for (int i = 0; i < FigCount; i++){
		FigList[i]->Draw(pOut);		//Call Draw function (virtual member fn)
	SelectedPrint();
	}
	
}
////////////////////////////////////////////////////////////////////////////////////
//Return a pointer to the input
Input *ApplicationManager::GetInput() const
{	return pIn; }
//Return a pointer to the output
Output *ApplicationManager::GetOutput() const
{	return pOut; }
////////////////////////////////////////////////////////////////////////////////////
void ApplicationManager::setcrntdraw(color draw) { crntdraw = draw; }
///////////////////////////////////////////////////////////////////////////////////
void ApplicationManager::setcrntfill(color fill) { crntfill = fill; }
///////////////////////////////////////////////////////////////////////////////////
color ApplicationManager::getcrntdraw()const { return crntdraw; }
//////////////////////////////////////////////////////////////////////////////////
void ApplicationManager::setClipboard(CFigure* clip) { Clipboard = clip;  }
///////////////////////////////////////////////////////////////////////////////////
CFigure* ApplicationManager::getClipboard() const { return Clipboard; }
///////////////////////////////////////////////////////////////////////////////////
color ApplicationManager::getcrntfill()const { return crntfill; }
///////////////////////////////////////////////////////////////////////////////////
// ////////////////////////////////////////////////////////////////////////////////
// function to update the status bar of selection 
void ApplicationManager::SelectedPrint() { 
	if (getselectedfignumber() == 1) {
		SelectedFig->PrintInfo(pOut);
	}
	else if (getselectedfignumber() > 1) {
		int r=0, s=0, h=0, c=0, t=0;
		string rect="", squ="", hex="", tri="", circ="";
		for (int i = 0; i < FigCount; i++) {
			if (FigList[i]->IsSelected()) {
				switch (FigList[i]->gettype())
				{
				case 'r':
					r++;
					rect = " Rectangle(s): " + to_string(r) + " ";
					break;
				case 's':
					s++;
					squ = " Square(s): " + to_string(s) + " ";
					break;
				case 't':
					t++;
					tri = " Triangle(s): " + to_string(t) + " ";
					break;
				case 'c':
					c++;
					circ = " Circle(s): " + to_string(c) + " ";
					break;
				case 'h':
					h++;
					hex = " Hexagon(s): " + to_string(h)+" ";
					break;
				}
			}
		}

		pOut->PrintMessage("Selected:" +rect+squ+tri+circ+hex);
	}

}
//////////////////////////////////////////////////////////////////////////////////
string ApplicationManager::color2string(color col) {
	if (col == RED) {
		return "Red";
	}
	else if (col == GREEN) {
		return "Green";
	}
	else if (col == BLUE)
		return "Blue";
	else if (col == YELLOW)
		return "Yellow";
	else if (col == ORANGE)
		return "Orange";
	else if (col == BLACK)
		return "Black";
	else
		return "No_Fill";

}

color ApplicationManager::String2color(string str)
{

	if (str == "Red") {
		return RED;
	}
	else if (str == "Green") {
		return GREEN;
	}
	else if (str == "Blue")
		return BLUE;
	else if (str == "Yellow")
		return YELLOW;
	else if (str == "Orange")
		return ORANGE;
	else if (str == "Black")
		return BLACK;
	else if (str == "No_Fill")
		return WHITE;
}
//==================================================================================//
//						Playmode Management Functions								//
//==================================================================================//
void ApplicationManager::initializeplay()
{
	for (int i = 0; i < FigCount;i++) {
		if (FigList[i]->IsSelected()) {
			FigList[i]->SetSelected(false);
			continue;
		}
		if (FigList[i]->getCut()) {
			FigList[i]->setCut(false);
			Clipboard = NULL;
		}
	}
	for (int i = 0; i < MaxFigCount; i++) { // make sure that array is empty in all trial
		PlayFigList[i] = NULL;
	}
	Playfigcount = 0;
	for (int i = 0; i < FigCount; i++) {
		char t = FigList[i]->gettype();
		switch (t)
		{
		case 'r':
			PlayFigList[Playfigcount] = new CRectangle(FigList[i]);
			PlayFigList[Playfigcount++]->SetID(FigList[i]->GetID());
			
			break;
		case 's':
			PlayFigList[Playfigcount] = new CSquare(FigList[i]);
			PlayFigList[Playfigcount++]->SetID(FigList[i]->GetID());

			break;
		case 'c':
			PlayFigList[Playfigcount] = new CCircle(FigList[i]);
			PlayFigList[Playfigcount++]->SetID(FigList[i]->GetID());

			break;
		case 't':
			PlayFigList[Playfigcount] = new CTriangle(FigList[i]);
			PlayFigList[Playfigcount++]->SetID(FigList[i]->GetID());

			break;
		case'h':
			PlayFigList[Playfigcount] = new CHexagon(FigList[i]);
			PlayFigList[Playfigcount++]->SetID(FigList[i]->GetID());

			break;
		}
	}
}
/////////////////////////////////////////////////////////////////////////////////////
void ApplicationManager::deallocateplay()
{
	Playfigcount = 0;
	for (int i = 0; i < Playfigcount;i++) {
		delete PlayFigList[i];
	}
}
/////////////////////////////////////////////////////////////////////////////////////
int ApplicationManager::picktype(char& shapeChoosen) {
	int randomshape;
	int count = 0;
	if (FigCount == 0)
		return -1; 
	while (true) {
		randomshape = rand() % 5;
		switch (randomshape)
		{
		case 0:
			shapeChoosen = 'r';
			break;
		case 1:
			shapeChoosen = 's';
			break;
		case 2:
			shapeChoosen = 'h';
			break;
		case 3:
			shapeChoosen = 't';
			break;
		case 4:
			shapeChoosen = 'c';
			break;
		}
		bool breaker = 0;
		for (int i = 0; i < FigCount; i++) {
			if (FigList[i]->gettype() == shapeChoosen) {
				breaker = 1;
				break;
			}
		}
		if (breaker == 1) {
			break;
		}
	}
	for (int i = 0; i < FigCount; i++) {
		if (FigList[i]->gettype() == shapeChoosen) {
			count++;
		}
	}
		return count;
}
//////////////////////////////////////////////////////////////////////////////////
int ApplicationManager::pickcolor(color& choosencolor)
{
	int randomcolor;
	int breakf = 1;
	for (int i = 0; i < FigCount; i++) {
		if (FigList[i]->getclr(false) != WHITE) {
			breakf = 0;
		}
	}
	if (FigCount == 0)
		return -1;
	if (breakf == 1)
		return -2;
	
	while (true) {
		randomcolor = rand() % 6;
		switch (randomcolor)
		{
		case 0:
			choosencolor = RED;
			break;
		case 1:
			choosencolor = GREEN;
			break;
		case 2:
			choosencolor = BLUE;
			break;
		case 3:
			choosencolor = YELLOW;
			break;
		case 4:
			choosencolor = ORANGE;
			break;
		case 5:
			choosencolor = BLACK;
			break;
		}
		bool breaker = 0;
		for (int i = 0; i < FigCount; i++) {
			if (FigList[i]->getclr(false) == choosencolor) {
				breaker = 1;
				break;
			}
		}
		if (breaker == 1) {
			break;
		}
	}
	int count = 0;
	for (int i = 0; i < FigCount;i++) {
		if (FigList[i]->getclr(false) == choosencolor) {
			count++;
		}
	}
	return count;
}
//////////////////////////////////////////////////////////////////////////////////
int ApplicationManager::picktype_color(char&shapeChoosen , color & choosencolor)
{

	int randomshape;
	int count = 0;
	int randomcolor;
	if (FigCount == 0)
		return -1;
	while (true) {
		randomshape = rand() % 5;
		randomcolor = rand() % 7;
		switch (randomshape)
		{
		case 0:
			shapeChoosen = 'r';
			break;
		case 1:
			shapeChoosen = 's';
			break;
		case 2:
			shapeChoosen = 'h';
			break;
		case 3:
			shapeChoosen = 't';
			break;
		case 4:
			shapeChoosen = 'c';
			break;
		}
		switch (randomcolor)
		{
		case 0:
			choosencolor = RED;
			break;
		case 1:
			choosencolor = GREEN;
			break;
		case 2:
			choosencolor = BLUE;
			break;
		case 3:
			choosencolor = YELLOW;
			break;
		case 4:
			choosencolor = ORANGE;
			break;
		case 5:
			choosencolor = BLACK;
			break;
		case 6:
			choosencolor = WHITE;
		}
		bool breaker = 0;
		for (int i = 0; i < FigCount; i++) {
			if (FigList[i]->gettype() == shapeChoosen && FigList[i]->getclr(false) == choosencolor) {
				breaker = 1;
				break;
			}
		}
		if (breaker == 1) {
			break;
		}
	}
	
	
	
	for (int i = 0; i < FigCount;i++) {
		if (FigList[i]->getclr(false) == choosencolor && FigList[i]->gettype() == shapeChoosen) {
			count++;
		}
	}
	return count;
}
//////////////////////////////////////////////////////////////////////////////////
bool ApplicationManager::GetFigureplaymode(int x, int y, CFigure** p)
{
	for (int i = 0; i < Playfigcount; i++) {
		if (PlayFigList[i]->Search(x, y)) {
			*p = PlayFigList[i];
			return true;
		}
	}
	return false;
}
////////////////////////////////////////////////////////////////////////////
void ApplicationManager::Deleteplaymode(CFigure* deletefig) {
	// outer for loop to see how many time the operation will be done 
	for (int i = 0;i < Playfigcount; i++) {   // first inner for loop to search for the selected figs and deleting them
		if (PlayFigList[i]->GetID() == deletefig->GetID()) {
			delete PlayFigList[i];
			for (int k = i; k < Playfigcount; k++) { // second inner for loop for rearranging the Figlist array
				PlayFigList[k] = PlayFigList[k + 1];
			}
			break;
		}

	}
	Playfigcount--;
}
/////////////////////////////////////////////////////////////////////////////////
void ApplicationManager::UpdatePlay() {
	for (int i = 0; i < Playfigcount; i++) {
		PlayFigList[i]->Draw(pOut);
	}
}
////////////////////////////////////////////////////////////////////////////////
//Destructor
ApplicationManager::~ApplicationManager()
{
	for (int i = 0; i < Playfigcount;i++)
		delete PlayFigList[i];
	for(int i=0; i<FigCount; i++)
		delete FigList[i];
	delete pIn;
	delete pOut;
	if (Clipboard != NULL && !Clipboard->getCut())
		delete Clipboard;
}
