#include "CutAction.h"
#include "..\ApplicationManager.h"
#include "..\GUI\input.h"
#include "..\GUI\Output.h"
#include"Action.h"
#include "..\Figures\CRectangle.h"
#include"..\Figures\CSquare.h"
#include"..\Figures\CTriangle.h"
#include"..\Figures\CHexagon.h"
#include"..\Figures\CCircle.h"
CutAction::CutAction(ApplicationManager* pApp) : Action(pApp) {
	p = NULL;
}
void CutAction::ReadActionParameters() {
	// No need for parameters
}
void CutAction::Execute() {
	int x, y; // dummy variables
	Output* pOut = pManager->GetOutput();
	Input* pIn = pManager->GetInput();
	if (pManager->getselectedfignumber() == 0) {
		pOut->PrintMessage("Please select a figure, Click to Continue");
		pIn->GetPointClicked(x, y);
		pOut->ClearStatusBar();
		return;
	}
	else if (pManager->getselectedfignumber() > 1) {
		pOut->PrintMessage("Please select one figure only, Click to Continue");
		pIn->GetPointClicked(x, y);
		pOut->ClearStatusBar();
		return;
	}
	if (pManager->getClipboard() != NULL && !pManager->getClipboard()->getCut()) 
		delete pManager->getClipboard();
	else if (pManager->getClipboard() != NULL &&pManager->getClipboard()->getCut()) {
		pManager->getClipboard()->setCut(false);
		pManager->setClipboard(NULL);
		pOut->ClearDrawArea();
	}
	p = pManager->GetselectedFig();
	p->setCut(true);
	pManager->setClipboard(p);
}