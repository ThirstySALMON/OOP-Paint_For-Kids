#include "..\ApplicationManager.h"
#include "Picktype.h"
#include "..\GUI\input.h"
#include "..\GUI\Output.h"
#include "..\Figures\CRectangle.h"
#include"..\Figures\CSquare.h"
#include"..\Figures\CTriangle.h"
#include"..\Figures\CHexagon.h"
#include"..\Figures\CCircle.h"

Picktype::Picktype(ApplicationManager* pApp) : Action(pApp) {

}
void Picktype::ReadActionParameters() {
	//no need to read any actions
}
void Picktype::Execute() {
	char choosen;
	string l; // variable to print to the user what to pick
	Input* pIn = pManager->GetInput();
	Output* pOut = pManager->GetOutput();
	int x, y, correct = 0, incorrect = 0;
	CFigure* p = NULL;
	figcount = pManager->picktype(choosen);
	if (figcount == -1) {
		pOut->PrintMessage("No Figures present , Click to Continue");
		pIn->GetPointClicked(x, y);
		pOut->ClearStatusBar();
		return;
	}

	switch (choosen)
	{
	case 'r':
		l = "Rectangles";
		break;
	case's':
		l = "Squares";
		break;
	case'h':
		l = "Hexagons";
		break;
	case'c':
		l = "Circles";
		break;
	case't':
		l = "Triangles";
		break;
	}
	
	pOut->PrintMessage("Pick all "+l);
	pManager->initializeplay();
	while (figcount > 0) {
		pIn->GetPointClicked(x, y);
		if (pManager->GetFigureplaymode(x, y, &p) && p->gettype()==choosen) {

			pOut->PrintMessage("Correct! Score: " + to_string(++correct) + " Misses: " + to_string(incorrect));
			figcount--;
			pManager->Deleteplaymode(p);
			pOut->ClearDrawArea();
			pManager->UpdatePlay();
		}
		else if (y > UI.height - UI.StatusBarHeight || y < UI.LineUnderTBWidth + UI.ToolBarHeight) {
			figcount = -1;
		}
		else {
			pOut->PrintMessage("Incorrect! Score: " + to_string(correct) + " Misses: " + to_string(++incorrect));
			if (p != NULL)
			pManager->Deleteplaymode(p);
			pOut->ClearDrawArea();
			pManager->UpdatePlay();
		}
	}
	if (figcount != -1)
		pOut->PrintMessage("Final Score : " + to_string(correct) + "     Mistakes: " + to_string(incorrect)+ "     Click to Continue");
	else
		pOut->PrintMessage("Game aborted , Click to Continue");
	pIn->GetPointClicked(x, y);
	pOut->ClearStatusBar();
}