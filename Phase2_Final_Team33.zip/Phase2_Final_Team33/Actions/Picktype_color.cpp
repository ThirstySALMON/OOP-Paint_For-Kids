#include "..\ApplicationManager.h"
#include "Picktype_color.h"
#include "..\GUI\input.h"
#include "..\GUI\Output.h"
#include "..\Figures\CRectangle.h"
#include"..\Figures\CSquare.h"
#include"..\Figures\CTriangle.h"
#include"..\Figures\CHexagon.h"
#include"..\Figures\CCircle.h"

Pickt_c::Pickt_c(ApplicationManager* pApp) : Action(pApp) {

}
void Pickt_c::ReadActionParameters() {
	//no need to read any actions
}
void Pickt_c::Execute() {
	char choosens; // choosenc shape
	color choosenc;// choosenc color
	string l; // variable to print to the user what to pick
	string c; // what color to pick
	Input* pIn = pManager->GetInput();
	Output* pOut = pManager->GetOutput();
	int x, y, correct = 0, incorrect = 0;
	CFigure* p = NULL;
	figcount = pManager->picktype_color(choosens , choosenc);
	if (figcount == -1) {
		pOut->PrintMessage("No Figures present , Click to Continue");
		pIn->GetPointClicked(x, y);
		pOut->ClearStatusBar();
		return;
	}

	switch (choosens)
	{
	case 'r':
		l = " Rectangles ";
		break;
	case's':
		l = " Squares";
		break;
	case'h':
		l = " Hexagons";
		break;
	case'c':
		l = " Circles";
		break;
	case't':
		l = " Triangles";
		break;
	}
	if (choosenc == RED)
		c = "Red";
	else if (choosenc == GREEN)
		c = "Green";
	else if (choosenc == BLUE)
		c = "Blue";
	else if (choosenc == YELLOW)
		c = "Yellow";
	else if (choosenc == ORANGE)
		c = "Orange";
	else if (choosenc == BLACK)
		c = "Black";
	else if (choosenc == WHITE)
		c = "Empty";

	pOut->PrintMessage("Pick all "+ c+ l);
	pManager->initializeplay();
	while (figcount > 0) {
		pIn->GetPointClicked(x, y);
		if (pManager->GetFigureplaymode(x, y, &p) && p->gettype() == choosens && p->getclr(false) == choosenc) {

			pOut->PrintMessage("Correct! Score: " + to_string(++correct) + " Misses: " + to_string(incorrect));
			figcount--;
			pManager->Deleteplaymode(p);
			pOut->ClearDrawArea();
			pManager->UpdatePlay();
		}
		else if (y > UI.height - UI.StatusBarHeight || y < UI.LineUnderTBWidth + UI.ToolBarHeight) {
			figcount = -1;
		}
		else {
			pOut->PrintMessage("Incorrect! Score: " + to_string(correct) + " Misses: " + to_string(++incorrect));
			if (p != NULL)

			pManager->Deleteplaymode(p);
			pOut->ClearDrawArea();
			pManager->UpdatePlay();
		}
	}
	if (figcount != -1)
		pOut->PrintMessage("Final Score : " + to_string(correct) + "     Mistakes: " + to_string(incorrect) + "     Click to Continue");
	else
		pOut->PrintMessage("Game aborted , Click to Continue");
	pIn->GetPointClicked(x, y);
	pOut->ClearStatusBar();
}