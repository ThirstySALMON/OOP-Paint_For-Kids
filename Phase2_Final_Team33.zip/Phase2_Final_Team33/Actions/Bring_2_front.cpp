#include "Bring_2_front.h"
#include "..\ApplicationManager.h"
#include "..\GUI\input.h"
#include "..\GUI\Output.h"
#include"Action.h"

bringfront::bringfront(ApplicationManager* pApp) : Action(pApp) {}
void bringfront::ReadActionParameters() {
	// no need to read any parameter
}
void bringfront::Execute() {
	int x, y; // dummy variables
	Output* pOut = pManager->GetOutput();
	Input* pIn = pManager->GetInput();
	if (pManager->getselectedfignumber() == 0) {
		pOut->PrintMessage("Please select a figure, Click to Continue");
		pIn->GetPointClicked(x, y);
		pOut->ClearStatusBar();
		return;
	}
	else if (pManager->getselectedfignumber() > 1) {
		pOut->PrintMessage("Please select one figure only, Click to Continue");
		pIn->GetPointClicked(x, y);
		pOut->ClearStatusBar();
		return;
	}
	

	pOut->ClearDrawArea();
	pManager->bring2front();
}