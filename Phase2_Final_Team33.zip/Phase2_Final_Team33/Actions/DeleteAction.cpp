#include "DeleteAction.h"
#include "..\ApplicationManager.h"
#include "..\GUI\input.h"
#include "..\GUI\Output.h"
#include"Action.h"
#include <iostream>

DeleteAction::DeleteAction(ApplicationManager* pApp) : Action(pApp) {}
void DeleteAction::ReadActionParameters() {
}
void DeleteAction::Execute() {
	Output* pOut = pManager->GetOutput();
	Input* pIn = pManager->GetInput();
	int x, y;
	if (pManager->getselectedfignumber() == 0) {
		pOut->PrintMessage("Please select a figure or more, Click to Continue");
		pIn->GetPointClicked(x, y);
		pOut->ClearStatusBar();
	}
	else   {
		
		pManager->DeleteselectedFigs();
		pOut->ClearDrawArea();
		pOut->ClearStatusBar();

	}

}
