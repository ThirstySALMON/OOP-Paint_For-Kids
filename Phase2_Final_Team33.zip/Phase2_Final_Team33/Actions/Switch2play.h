#include"Action.h"
#pragma once
class Switch2Play : public Action {
public:
	Switch2Play(ApplicationManager* pApp);
	virtual void ReadActionParameters();
	virtual void Execute();
};