#include "..\ApplicationManager.h"
#include "ClearAll.h"
#include "..\GUI\input.h"
#include "..\GUI\Output.h"
#include"Action.h"
ClearAll::ClearAll(ApplicationManager* pApp) : Action (pApp) {}
void ClearAll::ReadActionParameters()  {
	//no need for any input
	Output* pOut = pManager->GetOutput();
	pOut->ClearDrawArea();
	pOut->ClearStatusBar();

 }
void ClearAll::Execute() {
	ReadActionParameters();
	pManager->DeleteAll();
	pManager->setcrntdraw(BLUE);
	pManager->setcrntfill(WHITE);

	
}
