#pragma once
#include"Action.h"
#include "..\ApplicationManager.h"

class DeleteAction : public Action
{
private:
	CFigure* pCF;
public:
	DeleteAction(ApplicationManager* pApp);
	virtual void ReadActionParameters();
	virtual void Execute();
};