#pragma once
#include"Action.h"
class Pickcolor : public Action {
private:
	int figcount;
public:
	Pickcolor(ApplicationManager* pApp);
	virtual void ReadActionParameters();
	virtual void Execute();
};