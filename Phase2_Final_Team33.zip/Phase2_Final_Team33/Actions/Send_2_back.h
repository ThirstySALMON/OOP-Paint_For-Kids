#pragma once
#include"Action.h"
#include "..\ApplicationManager.h"
class Sendingback : public Action {
public:
	Sendingback(ApplicationManager* pApp);
	virtual void ReadActionParameters();
	virtual void Execute();
};