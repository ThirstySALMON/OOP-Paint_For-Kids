#include "Switch2play.h"
#include "..\ApplicationManager.h"
#include "..\GUI\input.h"
#include "..\GUI\Output.h"
#include"Action.h"
Switch2Play::Switch2Play(ApplicationManager* pApp) : Action(pApp){}
void Switch2Play::ReadActionParameters(){ //no need to read any parameters
}
void Switch2Play::Execute() {
	Output*pOut=pManager->GetOutput();
	pManager->initializeplay();
	pOut->ClearDrawArea();
	pOut->ClearToolbar(); // Clears tool bar so no overlap of icons occur
	pOut->CreatePlayToolBar();
}
