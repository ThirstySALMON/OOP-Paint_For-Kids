
#include "..\ApplicationManager.h"
#include "Select.h"
#include "..\GUI\input.h"
#include "..\GUI\Output.h"

SelectAct::SelectAct(ApplicationManager* pApp) : Action(pApp) {
	pCF = NULL; 
	
}
void SelectAct::ReadActionParameters(){
	Output* pOut = pManager->GetOutput();
	Input* pIn = pManager->GetInput();

	pOut->PrintMessage("Select a figure");
	pIn->GetPointClicked(P.x, P.y);
	pOut->ClearStatusBar();

}
void SelectAct::Execute() {
	Output* pOut = pManager->GetOutput();
	ReadActionParameters();
	pCF = pManager->GetFigure(P.x, P.y);
	if (pCF != NULL) { // Safety check 
		if (!pCF->IsSelected()) {
			pCF->SetSelected(true);
		}
		else {
			pCF->SetSelected(false);
		}
		if (pCF->getCut()) {
			pCF->setCut(false);
			pManager->setClipboard(NULL);
			pOut->ClearDrawArea();
		}
	}

	pManager->SetSelectedFig(NULL);
}
	