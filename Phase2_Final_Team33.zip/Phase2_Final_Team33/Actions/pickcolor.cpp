#include "..\ApplicationManager.h"
#include "Pickcolor.h"
#include "..\GUI\input.h"
#include "..\GUI\Output.h"
#include "..\Figures\CRectangle.h"
#include"..\Figures\CSquare.h"
#include"..\Figures\CTriangle.h"
#include"..\Figures\CHexagon.h"
#include"..\Figures\CCircle.h"

Pickcolor::Pickcolor(ApplicationManager* pApp) : Action(pApp) {

}
void Pickcolor::ReadActionParameters() {
	//no need to read any actions
}
void Pickcolor::Execute() {
	color choosen;
	string l;    // variable to print to the user what to pick
	Input* pIn = pManager->GetInput();
	Output* pOut = pManager->GetOutput();
	int x, y, correct = 0, incorrect = 0;
	CFigure* p = NULL;
	figcount = pManager->pickcolor(choosen);
	if (figcount == -2) {
		pOut->PrintMessage("No Colored Figures present , Click to Continue");
		pIn->GetPointClicked(x, y);
		pOut->ClearStatusBar();
		return;
	}
	else if (figcount == -1) {
		pOut->PrintMessage("No Figures present , Click to Continue");
		pIn->GetPointClicked(x, y);
		pOut->ClearStatusBar();
		return;
	}
	if (choosen == RED) 
			l= "Red";
	else if (choosen == GREEN) 
			l= "Green";
	else if (choosen == BLUE)
			l= "Blue";
	else if (choosen == YELLOW)
			l= "Yellow";
	else if (choosen == ORANGE)
			l= "Orange";
	else if (choosen == BLACK)
			l= "Black";
	

	pOut->PrintMessage("Pick all " + l+" figures");
	pManager->initializeplay();
	while (figcount > 0) {
		pIn->GetPointClicked(x, y);
		if (pManager->GetFigureplaymode(x, y, &p) && p->getclr(false) == choosen) {
			pOut->PrintMessage("Correct! Score: " + to_string(++correct) + " Misses: " + to_string(incorrect));
			figcount--;
			pManager->Deleteplaymode(p);
			pOut->ClearDrawArea();
			pManager->UpdatePlay();
		}
		else if (y > UI.height - UI.StatusBarHeight || y < UI.LineUnderTBWidth + UI.ToolBarHeight) {
			figcount = -1;
		}
		else {
			pOut->PrintMessage("Incorrect! Score: " + to_string(correct) + " Misses: " + to_string(++incorrect));
			if (p!=NULL)
			pManager->Deleteplaymode(p);
			pOut->ClearDrawArea();
			pManager->UpdatePlay();
		}
	}
	if (figcount != -1)
		pOut->PrintMessage("Final Score : " + to_string(correct) + "     Mistakes: " + to_string(incorrect) + "     Click to Continue");
	else
		pOut->PrintMessage("Game aborted , Click to Continue");
	pIn->GetPointClicked(x, y);
	pOut->ClearStatusBar();
}