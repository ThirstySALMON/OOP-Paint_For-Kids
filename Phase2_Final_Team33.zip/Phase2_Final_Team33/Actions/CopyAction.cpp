#include "CopyAction.h"
#include "..\ApplicationManager.h"
#include "..\GUI\input.h"
#include "..\GUI\Output.h"
#include"Action.h"
#include "..\Figures\CRectangle.h"
#include"..\Figures\CSquare.h"
#include"..\Figures\CTriangle.h"
#include"..\Figures\CHexagon.h"
#include"..\Figures\CCircle.h"
CopyAction::CopyAction(ApplicationManager* pApp) : Action(pApp) {
	breaker = 0;
	p = NULL;
}
void CopyAction::ReadActionParameters() {
	// No need to read actions from the user
}
void CopyAction::Execute() {
	int x, y; // dummy variables
	Output* pOut = pManager->GetOutput();
	Input* pIn = pManager->GetInput();
	if (pManager->getselectedfignumber() == 0) {
		pOut->PrintMessage("Please select a figure, Click to Continue");
		pIn->GetPointClicked(x, y);
		pOut->ClearStatusBar();

		return;
	}
	else if (pManager->getselectedfignumber() > 1) {
		pOut->PrintMessage("Please select one figure only, Click to Continue");
		pIn->GetPointClicked(x, y);
		pOut->ClearStatusBar();
		return;
	}
	if (pManager->getClipboard() != NULL && !pManager->getClipboard()->getCut() ){    // housekeeping 
		delete pManager->getClipboard();
	}
	if (pManager->getClipboard() != NULL && pManager->getClipboard()->getCut()) {
		pManager->getClipboard()->setCut(false);
		pManager->setClipboard(NULL);
		pOut->ClearDrawArea();
	}
	p = pManager->GetselectedFig();
	
	switch (p->gettype()) {
	case 'r':
		p = new CRectangle(p);
		break;
	case 's':
		p = new CSquare(p);
		break;
	case 'h':
		p = new CHexagon(p);
		break;
	case 't':
		p = new CTriangle(p);
		break;
	case 'c':
		p = new CCircle(p);
		break;
	}
	pManager->setClipboard(p);

}