#pragma once
#include"Action.h"
class Picktype : public Action {
private:
	int figcount;
public:
	Picktype(ApplicationManager* pApp);
	virtual void ReadActionParameters();
	virtual void Execute();
};