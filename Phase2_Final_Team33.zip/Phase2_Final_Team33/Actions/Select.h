#pragma once
#include "Action.h"
class SelectAct: public Action {
private:
	Point P;
	CFigure* pCF;//pointer to selected figure
	
public:
	SelectAct(ApplicationManager* pApp);
	virtual void ReadActionParameters();
	virtual void Execute();

};