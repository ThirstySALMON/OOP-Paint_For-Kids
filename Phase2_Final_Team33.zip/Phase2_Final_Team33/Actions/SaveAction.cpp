#include "..\ApplicationManager.h"
#include "SaveAction.h"
#include "..\GUI\input.h"
#include "..\GUI\Output.h"
SaveAction::SaveAction(ApplicationManager* pApp): Action (pApp) {
}

void SaveAction:: ReadActionParameters() {
	Input *pIn = pManager->GetInput();
	Output* pOut = pManager->GetOutput();
	pOut->PrintMessage("Type file name to save");
	filename=pIn->GetSrting(pOut);
}
void SaveAction::Execute() {

	ReadActionParameters();
	Output* pOut = pManager->GetOutput();
	Input* pIn = pManager->GetInput();
	int x, y;
	if (filename.empty()) {
		pOut->PrintMessage("Error! invalid name, Click to Continue");
		pIn->GetPointClicked(x, y);
		pOut->ClearStatusBar();
		return;
	}
	filename += ".txt";
	ofstream savefile;
	savefile.open("Save_Files/" + filename, ios::out);
	if (pManager->SaveAll(savefile) == 1) {
		pOut->PrintMessage("Error! No Figures, Click to Continue");
		pIn->GetPointClicked(x, y);
		pOut->ClearStatusBar();
	}
	
	savefile.close();
	pOut->PrintMessage("File Saved! Click to Continue");
	pIn->GetPointClicked(x, y);
	pOut->ClearStatusBar();
}