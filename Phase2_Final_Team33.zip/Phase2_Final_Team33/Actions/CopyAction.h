#pragma once
#include"Action.h"
#include "..\ApplicationManager.h"
class CopyAction : public Action {
private :
	bool breaker=0;
	CFigure* p;
public :
	CopyAction(ApplicationManager* pApp);
	virtual void ReadActionParameters();
	virtual void Execute();
};