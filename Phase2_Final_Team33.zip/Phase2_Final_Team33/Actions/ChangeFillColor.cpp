#include "..\ApplicationManager.h"
#include "ChangeFillColor.h"
#include "..\GUI\input.h"
#include "..\GUI\Output.h"
#include <iostream>

ChangeFillColor::ChangeFillColor(ApplicationManager* pApp) : Action(pApp) {
	selectedfig = pManager->GetselectedFig();
}
void ChangeFillColor::ReadActionParameters() {
	int x, y; // dummy variables
	Output* pOut = pManager->GetOutput();
	Input* pIn = pManager->GetInput();
	if (pManager->getselectedfignumber() == 0) {
		pOut->PrintMessage("Please select a figure, Click to Continue");
		pIn->GetPointClicked(x, y);
		breaker = 1;
		pOut->ClearStatusBar();
		return;
	}
	else if (pManager->getselectedfignumber() > 1) {
		pOut->PrintMessage("Please select one figure only, Click to Continue");
		pIn->GetPointClicked(x, y);
		breaker = 1;
		pOut->ClearStatusBar();

		return;
	}

	pOut->PrintMessage("Select a color");


	ActionType ColorChoosen = pManager->GetUserAction();
	switch (ColorChoosen)
	{
	case REDF:
		UserColor = RED;
		break;
	case GREENF:
		UserColor = GREEN;
		break;
	case BLUEF:
		UserColor = BLUE;
		break;
	case YELLOWF:
		UserColor = YELLOW;
		break;
	case ORANGEF:
		UserColor = ORANGE;
		break;
	case BLACKF:
		UserColor = BLACK;
		break;
	case NO_FILLF:
		UserColor = WHITE;
		break;
	default:
		UserColor = selectedfig->getclr(false);
		break;
	}
}
void ChangeFillColor::Execute() {
	ReadActionParameters();
	if (breaker == 1) {
		return;
	}
	
	Output* pOut = pManager->GetOutput();


	
	pOut->ClearStatusBar();
	pOut->ClearDrawArea();
	selectedfig->ChngFillClr(UserColor);
	pManager->setcrntfill(UserColor);

}