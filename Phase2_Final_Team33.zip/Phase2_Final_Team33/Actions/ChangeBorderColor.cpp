#include "..\ApplicationManager.h"
#include "ChangeBorderColor.h"
#include "..\GUI\input.h"
#include "..\GUI\Output.h"
#include <iostream>

ChangeBorderColor::ChangeBorderColor(ApplicationManager* pApp) : Action(pApp) {
	selectedfig = pManager->GetselectedFig();
}
void ChangeBorderColor::ReadActionParameters() {
	int x, y; // dummy variables
	Output* pOut = pManager->GetOutput();
	Input* pIn = pManager->GetInput();
	if (pManager->getselectedfignumber() == 0) {
		pOut->PrintMessage("Please select a figure, Click to Continue");
		pIn->GetPointClicked(x, y);
		pOut->ClearStatusBar();
		breaker = 1;
		return;
	}
	else if (pManager->getselectedfignumber() > 1) {
		pOut->PrintMessage("Please select one figure only, Click to Continue");
		pIn->GetPointClicked(x, y);
		pOut->ClearStatusBar();
		breaker = 1;
		return;
	}

	pOut->PrintMessage("Select a color");
	

	ActionType ColorChoosen = pManager->GetUserAction();
	switch (ColorChoosen)
	{
	case REDF:
		UserColor = RED;
		break;
	case GREENF:
		UserColor = GREEN;
		break;
	case BLUEF:
		UserColor = BLUE;
		break;
	case YELLOWF:
		UserColor = YELLOW;
		break;
	case ORANGEF:
		UserColor = ORANGE;
		break;
	case BLACKF:
		UserColor = BLACK;
		break;
	default:
		UserColor = selectedfig->getclr(true);

		break;
	}
}
void ChangeBorderColor::Execute() {
	ReadActionParameters();
	if (breaker == 1) {
		return;
	}
	
	Output* pOut = pManager->GetOutput();
	
	
	
	pOut->ClearStatusBar();
	selectedfig->ChngDrawClr(UserColor);
	pManager->setcrntdraw(UserColor);
}