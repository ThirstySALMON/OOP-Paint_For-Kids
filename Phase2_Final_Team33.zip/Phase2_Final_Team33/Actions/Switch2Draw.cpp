#include "Switch2Draw.h"
#include "..\ApplicationManager.h"
#include "..\GUI\input.h"
#include "..\GUI\Output.h"
#include"Action.h"
Switch2Draw::Switch2Draw(ApplicationManager* pApp) : Action(pApp) {}
void Switch2Draw::ReadActionParameters() { //no need to read any parameters
}
void Switch2Draw::Execute() {
	Output* pOut = pManager->GetOutput();
	pManager->deallocateplay();
	pOut->ClearToolbar(); // Clears tool bar so no overlap of icons occur
	pOut->ClearStatusBar();
	pOut->CreateDrawToolBar();
}
