#include "AddSquareAction.h"
#include "..\Figures\CSquare.h"

#include "..\ApplicationManager.h"

#include "..\GUI\input.h"
#include "..\GUI\Output.h"

AddSquareAction::AddSquareAction(ApplicationManager* pApp) :Action(pApp)
{}

void AddSquareAction::ReadActionParameters()
{
	//Get a Pointer to the Input / Output Interfaces
	Output* pOut = pManager->GetOutput();
	Input* pIn = pManager->GetInput();

	pOut->PrintMessage("New Square: Click at a point");

	//Read a point and store in point P1
	pIn->GetPointClicked(P1.x, P1.y);

	if (pManager->getcrntfill() == WHITE) {
		SquareGfxInfo.isFilled = false;
	}
	else {
		SquareGfxInfo.isFilled = true;
	}

	SquareGfxInfo.DrawClr = pManager->getcrntdraw();
	SquareGfxInfo.FillClr = pManager->getcrntfill();

	pOut->ClearStatusBar();

}

//Execute the action
void AddSquareAction::Execute()
{
	//This action needs to read some parameters first
	ReadActionParameters();

	//Create a square with the parameters read from the user
	CSquare* S = new CSquare(P1, SquareGfxInfo);

	//Add the square to the list of figures
	pManager->AddFigure(S);
}
