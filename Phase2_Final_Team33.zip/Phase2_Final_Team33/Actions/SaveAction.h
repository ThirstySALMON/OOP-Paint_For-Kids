#pragma once
#include "Action.h"
class SaveAction : public Action {
private:
	string filename;
public:
	SaveAction(ApplicationManager* pApp) ;
	virtual void ReadActionParameters();
	virtual void Execute();
};