#pragma once
#pragma once
#include "Action.h"
class ChangeFillColor : public  Action {
private:
	CFigure* selectedfig;
	color UserColor;
	bool breaker = 0; // to break the function if no figure selected
public:
	ChangeFillColor(ApplicationManager* pApp);
	virtual void ReadActionParameters();
	virtual void Execute();
};