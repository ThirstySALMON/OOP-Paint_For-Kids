#include "..\ApplicationManager.h"
#include "LoadAction.h"
#include "..\GUI\input.h"
#include "..\GUI\Output.h"
#include "..\Figures\CRectangle.h"
#include"..\Figures\CSquare.h"
#include"..\Figures\CTriangle.h"
#include"..\Figures\CHexagon.h"
#include"..\Figures\CCircle.h"
LoadAction::LoadAction(ApplicationManager* pApp) : Action(pApp) {
	p = NULL;
}

void LoadAction::ReadActionParameters() {
	Input* pIn = pManager->GetInput();
	Output* pOut = pManager->GetOutput();
	pOut->PrintMessage("Type file name to Load");
	filename = pIn->GetSrting(pOut);
}
void LoadAction::Execute() {
	ReadActionParameters();
	Output* pOut = pManager->GetOutput();
	Input* pIn = pManager->GetInput();
	int x, y;
	if (filename.empty()) {
		pOut->PrintMessage("Error! invalid name,  Click to Continue");
		pIn->GetPointClicked(x, y);
		pOut->ClearStatusBar();
		return;
	}
	filename += ".txt";
	ifstream savefile;
	savefile.open("Save_Files/" + filename, ios::in);
	if (!savefile.is_open()) {
		pOut->PrintMessage("No File with name """ + filename + """, Click to Continue");
		pIn->GetPointClicked(x, y);
		pOut->ClearStatusBar();
		return;
	}
	int iterator;
	string drawcol, fillcol;
	savefile >> fillcol >> drawcol>> iterator;
	pManager->setcrntdraw(pManager->String2color(drawcol));
	pManager->setcrntfill(pManager->String2color(fillcol));
	pManager->DeleteAll();
	pOut->ClearDrawArea();
	pOut->ClearStatusBar();
	
	for (int i = 0; i < iterator;i++) {
		char type;
		savefile >> type;
		switch (type)
		{
		case 'r':
			p = new CRectangle();
			p->Load(savefile);
			pManager->AddFigure(p);
			break;
		case 's':
			p = new CSquare();
			p->Load(savefile);
			pManager->AddFigure(p);
			break;
		case 't':
			p = new CTriangle();
			p->Load(savefile);
			pManager->AddFigure(p);
			break;
		case 'h':
			p = new CHexagon();
			p->Load(savefile);
			pManager->AddFigure(p);
			break;
		case 'c':
			p = new CCircle();
			p->Load(savefile);
			pManager->AddFigure(p);
			break;
		}
	}
	pOut->PrintMessage("File Loaded successfully!");
	savefile.close();
}

