#include "AddHexAction.h"
#include "..\Figures\CHexagon.h"

#include "..\ApplicationManager.h"

#include "..\GUI\input.h"
#include "..\GUI\Output.h"

	AddHexAction::AddHexAction(ApplicationManager* pApp) : Action(pApp) {}
	void AddHexAction:: ReadActionParameters() {
		Output* pOut = pManager->GetOutput();
		Input* pIn = pManager->GetInput();

		pOut->PrintMessage("New Hexagon: Click at Center");
		pIn->GetPointClicked(P1.x, P1.y);
		if (pManager->getcrntfill() == WHITE) {
			HexGfxInfo.isFilled = false;
		}
		else {
			HexGfxInfo.isFilled = true;
		}

		HexGfxInfo.DrawClr = pManager->getcrntdraw();
		HexGfxInfo.FillClr = pManager->getcrntfill();

		pOut->ClearStatusBar();

	}
	void AddHexAction:: Execute() {
		ReadActionParameters();
		CHexagon* H = new CHexagon(P1, HexGfxInfo);
		pManager->AddFigure(H);
	}
