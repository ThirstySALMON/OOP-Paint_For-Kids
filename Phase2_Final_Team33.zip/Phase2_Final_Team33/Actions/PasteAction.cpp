#include "PasteAction.h"
#include "..\ApplicationManager.h"
#include "..\GUI\input.h"
#include "..\GUI\Output.h"
#include "..\Figures\CRectangle.h"
#include"..\Figures\CSquare.h"
#include"..\Figures\CTriangle.h"
#include"..\Figures\CHexagon.h"
#include"..\Figures\CCircle.h"
PasteAction::PasteAction(ApplicationManager* pApp): Action(pApp)
{	
	p = NULL;
}
void PasteAction::ReadActionParameters() {
	Output* pOut = pManager->GetOutput();
	Input* pIn = pManager->GetInput();
	int x, y; // dummy variables
	if (pManager->getClipboard() == NULL) {
		pOut->PrintMessage("ClipBoard is Empty! Click to Continue");
		pIn->GetPointClicked(x, y);
		pOut->ClearStatusBar();
		breaker = 1;
		return;
	}
	pOut->PrintMessage("Click a point to paste");
		pIn->GetPointClicked(P1.x, P1.y);
	
}
void PasteAction::Execute() {
	ReadActionParameters();
	if (breaker == 1) {
		return;
	}
	p = pManager->getClipboard();
	if (!p->getCut() ){
		if (p->gettype() == 'r') {
			Point point1 = p->getcorner1(), p2 = p->getcorner2();
			int rectlength = abs(point1.x - p2.x);
			int rectwidth = abs(point1.y - p2.y);
			p2.x = P1.x + rectlength;
			p2.y = P1.y + rectwidth;
			p = new CRectangle(P1, p2, p->getGfx());
			p->SetSelected(false);
			pManager->AddFigure(p);
		}
		else if (p->gettype() == 's') {
			p = new CSquare(P1, p->getGfx());
			p->SetSelected(false);
			pManager->AddFigure(p);
		}
		else if (p->gettype() == 'h') {
			p = new CHexagon(P1, p->getGfx());
			p->SetSelected(false);
			pManager->AddFigure(p);
		}
		else if (p->gettype() == 'c') {
			Point circ;
			Point temp = p->getcorner1();
			Point cent = p->getcenter();
			circ.x = P1.x;
			circ.y = P1.y + (cent.y - temp.y);
			p = new CCircle(P1, circ, p->getGfx());
			p->SetSelected(false);
			pManager->AddFigure(p);
		}
		else if (p->gettype() == 't') {
			Point cor1 = p->getcorner1();
			Point cor2 = p->getcorner2();
			Point cor3 = p->getcorner3();
			int length1, length2, height1, height2;
			if (cor1.x < cor2.x && cor1.x < cor3.x) {
				length1 = cor2.x - cor1.x;
				length2 = cor3.x - cor1.x;
				height1 = (cor1.y - cor2.y) * -1;
				height2 = (cor1.y - cor3.y) * -1;
				cor2.x = P1.x + length1;
				cor2.y = P1.y + height1;
				cor3.x = P1.x + length2;
				cor3.y = P1.y + height2;
				p = new CTriangle(P1, cor2, cor3, p->getGfx());
				p->SetSelected(false);
				pManager->AddFigure(p);
			}
			else if (cor2.x < cor1.x && cor2.x < cor3.x) {
				length1 = cor1.x - cor2.x;
				length2 = cor3.x - cor2.x;
				height1 = (cor2.y - cor1.y) * -1;
				height2 = (cor2.y - cor3.y) * -1;
				cor1.x = P1.x + length1;
				cor1.y = P1.y + height1;
				cor3.x = P1.x + length2;
				cor3.y = P1.y + height2;
				p = new CTriangle(P1, cor1, cor3, p->getGfx());
				p->SetSelected(false);
				pManager->AddFigure(p);
			}
			else if (cor3.x < cor1.x && cor3.x < cor2.x) {
				length1 = cor1.x - cor3.x;
				length2 = cor2.x - cor3.x;
				height1 = (cor3.y - cor1.y) * -1;
				height2 = (cor3.y - cor2.y) * -1;
				cor1.x = P1.x + length1;
				cor1.y = P1.y + height1;
				cor2.x = P1.x + length2;
				cor2.y = P1.y + height2;
				p = new CTriangle(P1, cor1, cor2, p->getGfx());
				p->SetSelected(false);
				pManager->AddFigure(p);
			}
		}
	}
	else {
		if (p->gettype() == 'r') {
			Point point1 = p->getcorner1(), p2 = p->getcorner2();
			int rectlength = abs(point1.x - p2.x);
			int rectwidth = abs(point1.y - p2.y);
			p2.x = P1.x + rectlength;
			p2.y = P1.y + rectwidth;
			int length = abs(P1.x - p2.x);
			int height = abs((P1.y - p2.y));

			// next few blocks is to make sure that the rectangle is whithin bounds 
			if (P1.y < p2.y) {
				if (P1.y < UI.ToolBarHeight + UI.LineUnderTBWidth) {
					P1.y = 5 + UI.ToolBarHeight + UI.LineUnderTBWidth;
					p2.y = P1.y + height; // to maintain the size of the rectangle
				}
			}
			else {
				if (p2.y < UI.ToolBarHeight + UI.LineUnderTBWidth) {
					p2.y = 5 + UI.ToolBarHeight + UI.LineUnderTBWidth;
					P1.y = p2.y + height; // to maintain the size of the rectangle
				}
			}
			if (p2.y > P1.y) {
				if (p2.y > UI.height - UI.StatusBarHeight) {
					p2.y = UI.height - UI.StatusBarHeight - 5;
					P1.y = p2.y - height;
				}
			}
			else {
				if (P1.y > UI.height - UI.StatusBarHeight) {
					P1.y = UI.height - UI.StatusBarHeight - 5;
					p2.y = P1.y - height;
				}
			}
			// The next validation is done for copy / pasting since the program won't know if the triangle is of out of bounds or not 

			if (p2.x > P1.x) {
				if (p2.x > UI.width - length) {
					p2.x = UI.width - 20;
					P1.x = p2.x - length;
				}
			}
			else {
				if (P1.x > UI.width - length) {
					P1.x = UI.width - 20;
					p2.x = P1.x - length;
				}
			}
			p->setcorner1(P1);
			p->setcorner2(p2);
			p->setCut(false);
			pManager->setClipboard(NULL);
		
		}
		else if (p->gettype() == 's') {
			if (P1.x - 50 < 0) {
				P1.x = 55;

			}
			if (P1.x + 50 > UI.width - 50) {
				P1.x = UI.width - 50 - 20;
			}
			if (P1.y - 50 < UI.LineUnderTBWidth + UI.ToolBarHeight) {
				P1.y = UI.LineUnderTBWidth + UI.ToolBarHeight + 55;
			}
			if (P1.y + 50 > UI.height - UI.StatusBarHeight) {
				P1.y = UI.height - UI.StatusBarHeight - 55;

			}
			p->setcenter(P1);
			p->setCut(false);
			pManager->setClipboard(NULL);
		}
		else if (p->gettype() == 'h') {
			int* px = new int[6]; // Two dynamic arrays which will be the input for the polygon function
			int* py = new int[6];
			int length = 75; // length of hexagon
			px[0] = P1.x;  // Getting x coordinate of all vertices 
			px[1] = P1.x + sqrt(3) * length / 2;
			px[2] = P1.x + sqrt(3) * length / 2;
			px[3] = P1.x;
			px[4] = P1.x - sqrt(3) * length / 2;
			px[5] = P1.x - sqrt(3) * length / 2;
			py[0] = P1.y - length;  // Getting y coordinate of all vertices 
			py[1] = P1.y - length / 2;
			py[2] = P1.y + length / 2;
			py[3] = P1.y + length;
			py[4] = P1.y + length / 2;
			py[5] = P1.y - length / 2;
			if (py[0] < UI.ToolBarHeight + UI.LineUnderTBWidth) {
				int x = 5 + UI.ToolBarHeight + UI.LineUnderTBWidth - py[0];
				for (int i = 0; i < 6; i++) {
					py[i] += x;
				}
			}
			if (py[3] > 600) {
				int x = py[3] - 595;
				for (int i = 0; i < 6; i++) {
					py[i] -= x;
				}
			}
			if (px[5] < 0) {
				int x = px[5] - 5;
				for (int i = 0; i < 6; i++) {
					px[i] -= x;
				}
			}
			if (px[1] > UI.width - sqrt(3) * length / 2) {
				px[1] = UI.width - 20;
				px[0] = px[1] - sqrt(3) * length / 2;
				px[2] = px[1];
				px[3] = px[1] - sqrt(3) * length / 2;
				px[4] = px[1] - sqrt(3) * length;
				px[5] = px[1] - sqrt(3) * length;
			}
			this->P1.x = px[0];
			this->P1.y = py[0] + length;
			delete[]py;
			delete[]px;
			p->setcenter(P1);
			p->setCut(false);
			pManager->setClipboard(NULL);
		}
		else if (p->gettype() == 'c') {
			Point circ;
			Point temp = p->getcorner1();
			Point cent = p->getcenter();
			circ.x = P1.x;
			circ.y = P1.y - (cent.y - temp.y);
			int radius  = abs((cent.y - temp.y));
			cent.x = P1.x;
			cent.y = P1.y;
			if (2 * radius > 498) {
				radius = 245;
			circ.y = -radius + cent.y;
			}
			if (cent.y < 52) {
				cent.y = 52 + radius + 5;
			}
			if (cent.y > 550) {
				cent.y = 595 - radius;
			}
			if (cent.y - radius < 52) {
				cent.y = 52 + radius + 5;
			}
			if (cent.y + radius > 550) {
				cent.y = 595 - radius;

			}

			if (cent.x - radius < 0) {
				cent.x = radius + 5;
			}
			if (UI.width - radius < cent.x) {
				cent.x = UI.width - 20 - radius;
			}
			if (cent.y < UI.ToolBarHeight + UI.LineUnderTBWidth)
				cent.y = radius + 55;
			circ.x = cent.x;
			circ.y = cent.y - radius;
			p->setcenter(cent);
			p->setcorner1(circ);

			p->setCut(false);
			pManager->setClipboard(NULL);

		}
		else if (p->gettype() == 't') {
			Point cor1 = p->getcorner1();
			Point cor2 = p->getcorner2();
			Point cor3 = p->getcorner3();
			int length1, length2, height1, height2;
			if (cor1.x < cor2.x && cor1.x < cor3.x) {
				length1 = cor2.x - cor1.x;
				length2 = cor3.x - cor1.x;
				height1 = (cor1.y - cor2.y) * -1;
				height2 = (cor1.y - cor3.y) * -1;
				cor2.x = P1.x + length1;
				cor2.y = P1.y + height1;
				cor3.x = P1.x + length2;
				cor3.y = P1.y + height2;
				p->setcorner1(P1);
				p->setcorner2(cor2);
				p->setcorner3(cor3);
				p->setCut(false);
				pManager->setClipboard(NULL);
			}
			else if (cor2.x < cor1.x && cor2.x < cor3.x) {
				length1 = cor1.x - cor2.x;
				length2 = cor3.x - cor2.x;
				height1 = (cor2.y - cor1.y) * -1;
				height2 = (cor2.y - cor3.y) * -1;
				cor1.x = P1.x + length1;
				cor1.y = P1.y + height1;
				cor3.x = P1.x + length2;
				cor3.y = P1.y + height2;
				p->setcorner1(P1);
				p->setcorner2(cor1);
				p->setcorner3(cor3);
				p->setCut(false);
				pManager->setClipboard(NULL);
			}
			else if (cor3.x < cor1.x && cor3.x < cor2.x) {
				length1 = cor1.x - cor3.x;
				length2 = cor2.x - cor3.x;
				height1 = (cor3.y - cor1.y) * -1;
				height2 = (cor3.y - cor2.y) * -1;
				cor1.x = P1.x + length1;
				cor1.y = P1.y + height1;
				cor2.x = P1.x + length2;
				cor2.y = P1.y + height2;
				p = new CTriangle(P1, cor1, cor2, p->getGfx());
				p->setcorner1(P1);
				p->setcorner2(cor1);
				p->setcorner3(cor2);
				p->setCut(false);
				pManager->setClipboard(NULL);
			}
		}
		Output* pOut = pManager->GetOutput();
		pOut->ClearDrawArea();
		pOut->ClearStatusBar();
	}
	
	
}