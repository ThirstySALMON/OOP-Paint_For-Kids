#pragma once
#include"Action.h"
#include "..\ApplicationManager.h"
class PasteAction: public Action {
private:
	bool breaker = 0;
	Point P1;
	CFigure* p;

public:
	PasteAction(ApplicationManager* pApp);
	virtual void ReadActionParameters();
	virtual void Execute();





};