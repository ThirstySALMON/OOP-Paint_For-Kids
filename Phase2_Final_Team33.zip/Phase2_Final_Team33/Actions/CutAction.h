#pragma once
#include"Action.h"
#include "..\ApplicationManager.h"
class CutAction : public Action {
private:
	CFigure* p;
public:
	CutAction(ApplicationManager* pApp);
	virtual void ReadActionParameters();
	virtual void Execute();


};