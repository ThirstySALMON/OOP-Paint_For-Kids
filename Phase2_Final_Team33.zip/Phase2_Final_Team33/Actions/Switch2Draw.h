#include"Action.h"
#pragma once
class Switch2Draw : public Action {
public:
	Switch2Draw(ApplicationManager* pApp);
	virtual void ReadActionParameters();
	virtual void Execute();
};