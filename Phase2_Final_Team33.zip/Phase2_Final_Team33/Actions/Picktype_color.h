#pragma once
#include"Action.h"
class Pickt_c : public Action {
private:
	int figcount;
public:
	Pickt_c(ApplicationManager* pApp);
	virtual void ReadActionParameters();
	virtual void Execute();
};