#pragma once
#include "Action.h"
class ChangeBorderColor: public  Action {
private:
	CFigure* selectedfig;
	color UserColor;
	bool breaker = 0; // to break the function if no figure selected
public:
	ChangeBorderColor(ApplicationManager* pApp);
	virtual void ReadActionParameters();
	virtual void Execute();
};