#pragma once
#include"Action.h"
#include "..\ApplicationManager.h"
class bringfront : public Action {
public:
	bringfront(ApplicationManager* pApp);
	virtual void ReadActionParameters();
	virtual void Execute();
};