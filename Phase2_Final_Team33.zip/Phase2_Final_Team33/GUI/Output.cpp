#include "Output.h"
#include <math.h> // needed for sqrt
Output::Output()
{
	//Initialize user interface parameters
	UI.InterfaceMode = MODE_DRAW;
	
	UI.width = 1400;
	UI.height = 650;
	UI.wx = 5;
	UI.wy =5;

	
	UI.StatusBarHeight = 50;
	UI.ToolBarHeight = 50;
	UI.LineUnderTBWidth = 2;
	UI.MenuItemWidth = 48;
	
	UI.DrawColor = BLUE;	//Drawing color
	UI.FillColor = GREEN;	//Filling color
	UI.MsgColor = RED;		//Messages color
	UI.BkGrndColor = LIGHTGOLDENRODYELLOW;	//Background color
	UI.HighlightColor = MAGENTA;	//This color should NOT be used to draw figures. use if for highlight only
	UI.StatusBarColor = TURQUOISE;
	UI.PenWidth = 3;	//width of the figures frames

	
	//Create the output window
	pWind = CreateWind(UI.width, UI.height, UI.wx, UI.wy);
	//Change the title
	pWind->ChangeTitle("Paint for Kids - Programming Techniques Project - Spring 2024");
	
	CreateDrawToolBar();
	CreateStatusBar();
	
}


Input* Output::CreateInput() const
{
	Input* pIn = new Input(pWind);
	return pIn;
}

//======================================================================================//
//								Interface Functions										//
//======================================================================================//

window* Output::CreateWind(int w, int h, int x, int y) const
{ 
	window* pW = new window(w, h, x, y);
	pW->SetBrush(UI.BkGrndColor);
	pW->SetPen(UI.BkGrndColor, 1);
	pW->DrawRectangle(0, UI.ToolBarHeight, w, h);	
	return pW;
}
//////////////////////////////////////////////////////////////////////////////////////////
void Output::CreateStatusBar() const
{
	pWind->SetPen(UI.StatusBarColor, 1);
	pWind->SetBrush(UI.StatusBarColor);
	pWind->DrawRectangle(0, UI.height - UI.StatusBarHeight, UI.width, UI.height);
}
//////////////////////////////////////////////////////////////////////////////////////////
void Output::ClearStatusBar() const
{
	//Clear Status bar by drawing a filled white rectangle
	pWind->SetPen(UI.StatusBarColor, 1);
	pWind->SetBrush(UI.StatusBarColor);
	pWind->DrawRectangle(0, UI.height - UI.StatusBarHeight, UI.width, UI.height);
}
//////////////////////////////////////////////////////////////////////////////////////////
void Output::ClearToolbar() const
{
	pWind->SetPen(WHITE,1);
	pWind->SetBrush(WHITE);
	pWind->DrawRectangle(0, 0, UI.width, UI.ToolBarHeight);
}
//////////////////////////////////////////////////////////////////////////////////////////
void Output::CreateDrawToolBar() const
{
	UI.InterfaceMode = MODE_DRAW;

	//You can draw the tool bar icons in any way you want.
	//Below is one possible way
	
	//First prepare List of images for each menu item
	//To control the order of these images in the menu, 
	//reoder them in UI_Info.h ==> enum DrawMenuItem
	string MenuItemImages[DRAW_ITM_COUNT];
	MenuItemImages[ITM_RECT] = "images\\MenuItems\\Menu_Rect.jpg";
	MenuItemImages[ITM_SQUARE] = "images\\MenuItems\\Menu_Square.jpg";
	MenuItemImages[ITM_TRIANGLE] = "images\\MenuItems\\Menu_Tri.jpg";
	MenuItemImages[ITM_HEXAGON] = "images\\MenuItems\\Menu_Hexagon.jpg";
	MenuItemImages[ITM_CIRCLE] = "images\\MenuItems\\Menu_Circle.jpg";
	MenuItemImages[ITM_SELECT] = "images\\MenuItems\\Menu_Select.jpg";
	MenuItemImages[ITM_REDC] = "images\\MenuItems\\Menu_Red.jpg";
	MenuItemImages[ITM_GREENC] = "images\\MenuItems\\Menu_Green.jpg";
	MenuItemImages[ITM_BLUEC] = "images\\MenuItems\\Menu_Blue.jpg";
	MenuItemImages[ITM_ORANGEC] = "images\\MenuItems\\Menu_Orange.jpg";
	MenuItemImages[ITM_YELLOWC] = "images\\MenuItems\\Menu_Yellow.jpg";
	MenuItemImages[ITM_BLACKC] = "images\\MenuItems\\Menu_Black.jpg";
	MenuItemImages[ITM_NOFILL] = "images\\MenuItems\\Menu_NoFill.jpg";
	MenuItemImages[ITM_CBC] = "images\\MenuItems\\Menu_Bordor.jpg";
	MenuItemImages[ITM_CFC] = "images\\MenuItems\\Menu_Filling.jpg";
	MenuItemImages[ITM_CUT] = "images\\MenuItems\\Menu_Cut.jpg";
	MenuItemImages[ITM_COPY] = "images\\MenuItems\\Menu_Copy.jpg";
	MenuItemImages[ITM_PASTE] = "images\\MenuItems\\Menu_Paste.jpg";
	MenuItemImages[ITM_DELETE] = "images\\MenuItems\\Menu_Erase.jpg";
	MenuItemImages[ITM_CLEAR_ALL] = "images\\MenuItems\\Menu_Clear.jpg";
	MenuItemImages[ITM_STB] = "images\\MenuItems\\Menu_STB.jpg";
	MenuItemImages[ITM_BTF] = "images\\MenuItems\\Menu_BTF.jpg";
	MenuItemImages[ITM_SAVEFIGS] = "images\\MenuItems\\Menu_Save.jpg";
	MenuItemImages[ITM_LOADFIGS] = "images\\MenuItems\\Menu_Load.jpg";
	MenuItemImages[ITM_VOICE] = "images\\MenuItems\\Menu_Voice.jpg";
	MenuItemImages[ITM_SWITCHPLAY] = "images\\MenuItems\\Menu_PlayM.jpg";
	MenuItemImages[ITM_EXIT] = "images\\MenuItems\\Menu_Exit.jpg";
	//TODO: Prepare images for each menu item and add it to the list

	//Draw menu item one image at a time
	for(int i=0; i<DRAW_ITM_COUNT; i++)
		pWind->DrawImage(MenuItemImages[i], i*UI.MenuItemWidth, 0, UI.MenuItemWidth, UI.ToolBarHeight);



	//Draw a line under the toolbar
	pWind->SetPen(RED, UI.LineUnderTBWidth);
	pWind->DrawLine(0, UI.ToolBarHeight, UI.width, UI.ToolBarHeight);

}
//////////////////////////////////////////////////////////////////////////////////////////

void Output::CreatePlayToolBar() const
{
	UI.InterfaceMode = MODE_PLAY;
	string menuitemsplay[PlayMenuItem::PLAY_ITM_COUNT];
	menuitemsplay[ITM_PICK_TYPE] = "images\\MenuItems\\Menu_ptype.jpg";
	menuitemsplay[ITM_PICK_COLOR] = "images\\MenuItems\\Menu_Pcolor.jpg";
	menuitemsplay[ITM_PICK_COLOR_AND_TYPE] = "images\\MenuItems\\Menu_PCT.jpg";
	menuitemsplay[ITM_SWITCH2DRAW] = "images\\MenuItems\\Menu_Draw.jpg";
	menuitemsplay[ITM_EXIT2] = "images\\MenuItems\\Menu_Exit.jpg";
	for (int i = 0; i < PLAY_ITM_COUNT; i++)
		pWind->DrawImage(menuitemsplay[i], i * UI.MenuItemWidth, 0, UI.MenuItemWidth, UI.ToolBarHeight);
	///TODO: write code to create Play mode menu

}
//////////////////////////////////////////////////////////////////////////////////////////

void Output::ClearDrawArea() const
{
	pWind->SetPen(UI.BkGrndColor, 1);
	pWind->SetBrush(UI.BkGrndColor);
	pWind->DrawRectangle(0, UI.ToolBarHeight + UI.LineUnderTBWidth, UI.width, UI.height - UI.StatusBarHeight);
}
//////////////////////////////////////////////////////////////////////////////////////////

void Output::PrintMessage(string msg) const	//Prints a message on status bar
{
	ClearStatusBar();	//First clear the status bar
	
	pWind->SetPen(UI.MsgColor, 50);
	pWind->SetFont(20, BOLD , BY_NAME, "Arial");   
	pWind->DrawString(10, UI.height - (int)(UI.StatusBarHeight/1.5), msg);
}
//////////////////////////////////////////////////////////////////////////////////////////

color Output::getCrntDrawColor() const	//get current drawing color
{	return UI.DrawColor;	}
//////////////////////////////////////////////////////////////////////////////////////////

color Output::getCrntFillColor() const	//get current filling color
{	return UI.FillColor;	}
//////////////////////////////////////////////////////////////////////////////////////////
	
int Output::getCrntPenWidth() const		//get current pen width
{	return UI.PenWidth;	}



//======================================================================================//
//								Figures Drawing Functions								//
//======================================================================================//

void Output::DrawRect(Point P1, Point P2, GfxInfo RectGfxInfo, bool selected) const
{
	color DrawingClr;
	if(selected)	
		DrawingClr = UI.HighlightColor; //Figure should be drawn highlighted
	else			
		DrawingClr = RectGfxInfo.DrawClr;
	
	pWind->SetPen(DrawingClr,UI.PenWidth);
	drawstyle style;
	if (RectGfxInfo.isFilled)	
	{
		style = FILLED;		
		pWind->SetBrush(RectGfxInfo.FillClr);
	}
	else	
		style = FRAME;
	pWind->DrawRectangle(P1.x, P1.y, P2.x, P2.y, style);
	
}
//////////////////////////////////////////////////////////////////////////////////////////
void Output::DrawTri(Point P1, Point P2, Point P3, GfxInfo TriGfxInfo, bool selected ) const
{
	color DrawingClr;
	if (selected)
		DrawingClr = UI.HighlightColor; //Figure should be drawn highlighted
	else
		DrawingClr = TriGfxInfo.DrawClr;

	pWind->SetPen(DrawingClr, UI.PenWidth);
	drawstyle style;
	if (TriGfxInfo.isFilled)
	{
		style = FILLED;
		pWind->SetBrush(TriGfxInfo.FillClr);
	}
	else
		style = FRAME;
	pWind->DrawTriangle(P1.x, P1.y, P2.x, P2.y, P3.x, P3.y, style);
}
//////////////////////////////////////////////////////////////////////////////////////////
void Output::Drawc(Point Point1, Point Point2, GfxInfo circleGfxInfo, bool selected) const
{
	color DrawingClr;
	if (selected)
		DrawingClr = UI.HighlightColor; //Figure should be drawn highlighted
	else 
		DrawingClr = circleGfxInfo.DrawClr;
	
	pWind->SetPen(DrawingClr, UI.PenWidth);
	drawstyle style;
	if (circleGfxInfo.isFilled)
	{
		style = FILLED;
		pWind->SetBrush(circleGfxInfo.FillClr);
	}
	else
		style = FRAME;
	int radius = sqrt(((Point2.x - Point1.x) * (Point2.x - Point1.x)) + ((Point2.y - Point1.y) * (Point2.y - Point1.y)));
	
	pWind->DrawCircle(Point1.x, Point1.y, radius, style);
}
//////////////////////////////////////////////////////////////////////////////////////////
void Output::DrawSquare(Point P1, GfxInfo SquareGfxInfo, bool selected) const
{	//Since a square is just special type of rectangle we will just use the DrawRect function with a few modifications
	Point P2;// Declare an extra point to be used as our second input
	int half_length = 50; // Half length of square side so it can be changed easily
	P2.x = P1.x - half_length; // to create a square of sides 100 px
	P2.y = P1.y - half_length;
	P1.x += half_length;
	P1.y += half_length;
	
	DrawRect(P2, P1, SquareGfxInfo, selected);
}
//////////////////////////////////////////////////////////////////////////////////////////
void Output::DrawHexagon(Point P1, GfxInfo HexaGfxInfo, bool selected ) const
{
	color DrawingClr;
	if (selected)
		DrawingClr = UI.HighlightColor; //Figure should be drawn highlighted
	else
		DrawingClr = HexaGfxInfo.DrawClr;

	pWind->SetPen(DrawingClr, UI.PenWidth);
	drawstyle style;
	if (HexaGfxInfo.isFilled)
	{
		style = FILLED;
		pWind->SetBrush(HexaGfxInfo.FillClr);
	}
	else
		style = FRAME;
	// We will use the DrawPolygon function and using the symmetrical properties of hexagons we can deduce the coordiantes of it's six vertices from its center
	int* px = new int[6]; // Two dynamic arrays which will be the input for the polygon function
	int* py = new int[6];
	int length = 75; // length of hexagon
	px[0] = P1.x;  // Getting x coordinate of all vertices 
	px[1] = P1.x+sqrt(3)* length /2;
	px[2] = P1.x+sqrt(3)* length /2;
	px[3] = P1.x;
	px[4] = P1.x-sqrt(3)* length /2;
	px[5] = P1.x- sqrt(3)* length / 2;
	py[0] = P1.y- length;  // Getting y coordinate of all vertices 
	py[1] = P1.y - length /2;
	py[2] = P1.y + length /2;
	py[3] = P1.y+ length;
	py[4] = P1.y + length /2;
	py[5] = P1.y - length /2; 
	
	pWind->DrawPolygon(px,py, 6 , style);
	delete[] px;
	delete[] py; // Cleanup
}
/////////////////////////////////////////////////////////////////////////////////////////
Output::~Output()
{
	delete pWind;
}

