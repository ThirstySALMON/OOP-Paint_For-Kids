#include "Input.h"
#include "Output.h"
#include<iostream>

Input::Input(window* pW) 
{
	pWind = pW; //point to the passed window
}

void Input::GetPointClicked(int &x, int &y) const
{
	pWind->WaitMouseClick(x, y);	//Wait for mouse click
}

string Input::GetSrting(Output *pO) const 
{
	string Label;
	char Key;
	while(1)
	{
		pWind->WaitKeyPress(Key);
		if(Key == 27 )	//ESCAPE key is pressed
			return "";	//returns nothing as user has cancelled label
		if(Key == 13 )	//ENTER key is pressed
			return Label;
		if((Key == 8) && (Label.size() >= 1))	//BackSpace is pressed
			Label.resize(Label.size() -1 );			
		else
			Label += Key;
		if (pO)
			pO->PrintMessage(Label);
	}
}

//This function reads the position where the user clicks to determine the desired action
ActionType Input::GetUserAction() const
{	
	int x,y;
	pWind->WaitMouseClick(x, y);	//Get the coordinates of the user click
	
	if(UI.InterfaceMode == MODE_DRAW)	//GUI in the DRAW mode
	{
		//[1] If user clicks on the Toolbar
		if ( y >= 0 && y < UI.ToolBarHeight)
		{	
			//Check whick Menu item was clicked
			//==> This assumes that menu items are lined up horizontally <==
			int ClickedItemOrder = (x / UI.MenuItemWidth);
			//Divide x coord of the point clicked by the menu item width (int division)
			//if division result is 0 ==> first item is clicked, if 1 ==> 2nd item and so on

			switch (ClickedItemOrder)
			{
			case ITM_RECT: return DRAW_RECT;
			case ITM_SQUARE: return DRAW_SQUARE;
			case ITM_TRIANGLE: return DRAW_TRIANGLE;
			case ITM_HEXAGON: return DRAW_HEXAGON;
			case ITM_CIRCLE: return DRAW_CIRCLE;
			case ITM_SELECT: return SELECT_FIGURE;
			case ITM_REDC: return REDF;
			case ITM_GREENC: return GREENF;
			case ITM_BLUEC: return BLUEF;
			case ITM_YELLOWC: return YELLOWF;
			case ITM_ORANGEC: return ORANGEF;
			case ITM_BLACKC: return BLACKF;
			case ITM_NOFILL: return NO_FILLF;
			case ITM_CBC: return CHANGE_B_COLOR;
			case ITM_CFC: return CHANGE_F_COLOR;
			case ITM_COPY: return COPYF;
			case ITM_CUT: return CUTF;
			case ITM_PASTE: return PASTEF;
			case ITM_DELETE: return DELETEF;
			case ITM_CLEAR_ALL: return  CLEAR_ALLF;
			case ITM_STB:return  SEND2BACK;
			case ITM_BTF:return BRING2FRONT;
			case ITM_SAVEFIGS:return SAVEF;
			case ITM_LOADFIGS:return LOADF;
			case ITM_SWITCHPLAY:return TO_PLAY;
			case ITM_VOICE:return VOICE_TOGGLE;

			case ITM_EXIT: return EXIT;	
			
			
			default: return EMPTY;	//A click on empty place in desgin toolbar
			}
			std::cout << ClickedItemOrder;
		}

		//[2] User clicks on the drawing area
		if ( y >= UI.ToolBarHeight && y < UI.height - UI.StatusBarHeight)
		{
			return DRAWING_AREA;	
		}
		
		//[3] User clicks on the status bar
		return STATUS;
	}
	else	//GUI is in PLAY mode
	{
		if (y >= 0 && y < UI.ToolBarHeight)
		{
			
			int ClickedItemOrder = (x / UI.MenuItemWidth);
			

			switch (ClickedItemOrder)
			{
			case ITM_PICK_TYPE: return PICKT;
			case ITM_PICK_COLOR_AND_TYPE: return PICKCT;
			case ITM_PICK_COLOR: return PICKC;
			case ITM_SWITCH2DRAW: return TO_DRAW;
			case ITM_EXIT2: return EXIT;
			
			default: return EMPTY;	//A click on empty place in desgin toolbar
			}
		}
		if (y >= UI.ToolBarHeight && y < UI.height - UI.StatusBarHeight)
		{
			return DRAWING_AREA;
		}

		//[3] User clicks on the status bar
		return STATUS;
		///TODO:
		//perform checks similar to Draw mode checks above
		//and return the correspoding action
		return TO_PLAY;	//just for now. This should be updated
	}	

}
/////////////////////////////////
	
Input::~Input()
{
}
