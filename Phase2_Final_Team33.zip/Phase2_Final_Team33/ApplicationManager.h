#ifndef APPLICATION_MANAGER_H
#define APPLICATION_MANAGER_H

#include "DEFS.h"
#include "Figures\CFigure.h"
#include "GUI\input.h"
#include "GUI\output.h"

//Main class that manages everything in the application.
class ApplicationManager
{
	enum { MaxFigCount = 200 };	//Max no of figures

private:
	int FigCount;//Actual number of figures
	int Playfigcount;
	bool voice_on;
	CFigure* FigList[MaxFigCount];	//List of all figures (Array of pointers)
	CFigure* PlayFigList[MaxFigCount]; // List of figures in playmode
	CFigure* SelectedFig; //Pointer to the selected figure 
	//Pointers to Input and Output classes
	Input *pIn;
	Output *pOut;
	color crntfill;
	color crntdraw;
	CFigure* Clipboard;  //Pointer to copied/cut figure

public:	
	ApplicationManager(); 
	~ApplicationManager();
	
	// -- Action-Related Functions
	//Reads the input command from the user and returns the corresponding action type
	ActionType GetUserAction() const;
	void ExecuteAction(ActionType) ; //Creates an action and executes it
	// -- Figures Management Functions
	CFigure* GetFigure(int x, int y) const; //Search for a figure given a point inside the figure
	CFigure* GetselectedFig() const; // returns the selected figure 
	CFigure* getClipboard()const;
	void SetSelectedFig(CFigure* figure); // Sets the selected figure 
	void setcrntfill(color fill); 
	void setcrntdraw(color fill); 
	void setClipboard(CFigure*);
	void AddFigure(CFigure* pFig);  //Adds a new figure to the FigList
	void DeleteselectedFigs();
	void DeleteAll(); // Resets the application
	void send2back(); 
	void bring2front();  
	color getcrntfill() const; 
	color getcrntdraw() const;  
	// -- Interface Management Functions
	Input *GetInput() const; //Return pointer to the input
	Output *GetOutput() const; //Return pointer to the output
	void SelectedPrint() ; // Checks if there are any selected figures and prints info 
	void UpdateInterface() ;	//Redraws all the drawing window
	int SaveAll(ofstream&);
	//Plamode Functions----
	void initializeplay(); // Initializes Play mode figure list 
	void deallocateplay(); // Free up memory
	int picktype(char&); // picks a type
	int pickcolor(color&); // picks a color
	int picktype_color(char&, color&); // picks a type and color
	void Deleteplaymode(CFigure*); // Deletes the figure when a user click on the correct figure
	bool GetFigureplaymode(int x, int y, CFigure**); // search for a figure in play mode
	void UpdatePlay(); // updates interface to remove selected Figures
	// Miscellaneous Functions--
	int getselectedfigindex()const; // returms index of selected if figure, if more than one fig selected returns -1
	int getselectedfignumber(); // gets the number of figures selected 
	string color2string(color);
	color String2color(string);

};

#endif