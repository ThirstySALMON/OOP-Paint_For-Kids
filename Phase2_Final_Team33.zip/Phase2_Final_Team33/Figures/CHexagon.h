
#include"CFigure.h"
class CHexagon : public CFigure
{
private:
public:
	 CHexagon(Point Center, GfxInfo FigureGfxInfo);
	 CHexagon(CFigure*);
	 CHexagon();
	virtual void Draw(Output* pOut) const;
	virtual bool Search(int x , int y );
	virtual void PrintInfo(Output* pOut);
	virtual void Save(ofstream&);
	virtual void Load(ifstream&);

};
