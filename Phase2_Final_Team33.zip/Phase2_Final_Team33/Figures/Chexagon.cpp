#include "CHexagon.h"
CHexagon::CHexagon(Point center, GfxInfo FigureGfxInfo) :CFigure(FigureGfxInfo , center, center, center, center) {
	shapetype = 'h';


	int* px = new int[6]; // Two dynamic arrays which will be the input for the polygon function
	int* py = new int[6];
	int length = 75; // length of hexagon
	px[0] = Center.x;  // Getting x coordinate of all vertices 
	px[1] = Center.x + sqrt(3) * length / 2;
	px[2] = Center.x + sqrt(3) * length / 2;
	px[3] = Center.x;
	px[4] = Center.x - sqrt(3) * length / 2;
	px[5] = Center.x - sqrt(3) * length / 2;
	py[0] = Center.y - length;  // Getting y coordinate of all vertices 
	py[1] = Center.y - length / 2;
	py[2] = Center.y + length / 2;
	py[3] = Center.y + length;
	py[4] = Center.y + length / 2;
	py[5] = Center.y - length / 2;
	if (py[0] < UI.ToolBarHeight + UI.LineUnderTBWidth) {
		int x = 5 + UI.ToolBarHeight + UI.LineUnderTBWidth - py[0];
		for (int i = 0; i < 6; i++) {
			py[i] += x;
		}
	}
	if (py[3] > 600) {
		int x = py[3] - 595;
		for (int i = 0; i < 6; i++) {
			py[i] -= x;
		}
	}
	if (px[5] < 0) {
		int x = px[5] - 5;
		for (int i = 0; i < 6; i++) {
			px[i] -= x;
		}
	}
	if (px[1] > UI.width - sqrt(3) * length / 2) {
		px[1] = UI.width - 20;
		px[0] = px[1] - sqrt(3) * length / 2;
		px[2] = px[1];
		px[3] = px[1] - sqrt(3) * length / 2;
		px[4] = px[1] - sqrt(3) * length;
		px[5] = px[1] - sqrt(3) * length;
	}
	this->Center.x = px[0];
	this->Center.y = py[0] + length;
	delete[]py;
	delete[]px;
}
CHexagon::CHexagon(CFigure*temp):CFigure(temp->getGfx(), temp->getcenter(), temp->getcorner1(), temp->getcorner2(), temp->getcorner3()){
	shapetype = 'h';


	int* px = new int[6]; // Two dynamic arrays which will be the input for the polygon function
	int* py = new int[6];
	int length = 75; // length of hexagon
	px[0] = Center.x;  // Getting x coordinate of all vertices 
	px[1] = Center.x + sqrt(3) * length / 2;
	px[2] = Center.x + sqrt(3) * length / 2;
	px[3] = Center.x;
	px[4] = Center.x - sqrt(3) * length / 2;
	px[5] = Center.x - sqrt(3) * length / 2;
	py[0] = Center.y - length;  // Getting y coordinate of all vertices 
	py[1] = Center.y - length / 2;
	py[2] = Center.y + length / 2;
	py[3] = Center.y + length;
	py[4] = Center.y + length / 2;
	py[5] = Center.y - length / 2;
	if (py[0] < UI.ToolBarHeight + UI.LineUnderTBWidth) {
		int x = 5 + UI.ToolBarHeight + UI.LineUnderTBWidth - py[0];
		for (int i = 0; i < 6; i++) {
			py[i] += x;
		}
	}
	if (py[3] > 600) {
		int x = py[3] - 595;
		for (int i = 0; i < 6; i++) {
			py[i] -= x;
		}
	}
	if (px[5] < 0) {
		int x = px[5] - 5;
		for (int i = 0; i < 6; i++) {
			px[i] -= x;
		}
	}
	if (px[1] > UI.width - sqrt(3) * length / 2) {
		px[1] = UI.width - 20;
		px[0] = px[1] - sqrt(3) * length / 2;
		px[2] = px[1];
		px[3] = px[1] - sqrt(3) * length / 2;
		px[4] = px[1] - sqrt(3) * length;
		px[5] = px[1] - sqrt(3) * length;
	}
	this->Center.x = px[0];
	this->Center.y = py[0] + length;
	delete[]py;
	delete[]px; }

void CHexagon::Draw(Output* pOut) const {
	pOut->DrawHexagon(Center, FigGfxInfo, Selected);
	
}
bool CHexagon::Search(int x, int y) {
	
	Point P[6] ;
	Point input; // To be able to be used in triangle function
	input.x = x;
	input.y = y; 
	int length = 75; // length of hexagon
	P[0].x = Center.x;  // Getting x coordinate of all vertices 
	P[1].x = Center.x + sqrt(3) * length / 2;
	P[2].x = Center.x + sqrt(3) * length / 2;
	P[3].x = Center.x;
	P[4].x = Center.x - sqrt(3) * length / 2;
	P[5].x = Center.x - sqrt(3) * length / 2;
	P[0].y = Center.y - length;  // Getting y coordinate of all vertices 
	P[1].y = Center.y - length / 2;
	P[2].y = Center.y + length / 2;
	P[3].y = Center.y + length;
	P[4].y = Center.y + length / 2;
	P[5].y = Center.y - length / 2;
	
	if (input.y >= P[0].y && input.y <= P[5].y) {
		return TriChecker(P[0], P[1], P[5], input);
	}
	else if (input.y >= P[2].y && input.y <= P[3].y) {
		return TriChecker(P[3], P[4], P[2], input);
	}
	else if (input.y > P[1].y && input.y < P[2].y && input.x > P[5].x && input.x < P[1].x) {
		return true;
	}
	return false;
}
CHexagon::CHexagon() { shapetype = 'h';	
}
void CHexagon::PrintInfo(Output* pOut) {
	string id = to_string(ID);
	
	string bc = Color2string(Brdrcolor);
	string fc = Color2string(Fillcolor);

	pOut->PrintMessage("Hexagon ID: " + id + "    Border Color: " + bc + "    Fill Color: " + fc);

}
void CHexagon::Save(ofstream& savefile) {

	savefile << shapetype << " " << ID << " " << Center.x << " " << Center.y << " " << Color2string(Brdrcolor) << " " << Color2string(Fillcolor) << endl;
}
void CHexagon::Load(ifstream&savefile) {
	string d, f;
	savefile >> ID >> Center.x >> Center.y >> d >> f;
	ChngDrawClr(String2color(d));
	ChngFillClr(String2color(f));
}