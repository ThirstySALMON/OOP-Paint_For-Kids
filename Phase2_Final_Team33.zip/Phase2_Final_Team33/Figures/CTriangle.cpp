#include "CTriangle.h"
#include"math.h"
CTriangle::CTriangle(Point P1, Point P2, Point P3, GfxInfo FigureGfxInfo) :CFigure(FigureGfxInfo ,P1 , P1 , P2 , P3)
{

	shapetype = 't';

		// these if statements are used to chekc that the points are whithin boundries
	if (Corner1.y < UI.LineUnderTBWidth + UI.ToolBarHeight) {
		Corner1.y = UI.LineUnderTBWidth + UI.ToolBarHeight + 2;
		Corner2.y += UI.LineUnderTBWidth + UI.ToolBarHeight + 2;
		Corner3.y += UI.LineUnderTBWidth + UI.ToolBarHeight + 2;
	}
	if (Corner2.y < UI.LineUnderTBWidth + UI.ToolBarHeight) {
		Corner2.y = UI.LineUnderTBWidth + UI.ToolBarHeight + 2;
		Corner3.y += UI.LineUnderTBWidth + UI.ToolBarHeight + 2;
		Corner1.y += UI.LineUnderTBWidth + UI.ToolBarHeight + 2;
	}

	if (Corner3.y < UI.LineUnderTBWidth + UI.ToolBarHeight) {
		Corner3.y = UI.LineUnderTBWidth + UI.ToolBarHeight + 2;
		Corner2.y += UI.LineUnderTBWidth + UI.ToolBarHeight + 2;
		Corner1.y += UI.LineUnderTBWidth + UI.ToolBarHeight + 2;
	}

	if (Corner1.y > UI.height - UI.StatusBarHeight) {
		Corner1.y = UI.height - UI.StatusBarHeight - 2;
		Corner2.y -= 2;
		Corner3.y -= 2;
	}
	if (Corner2.y > UI.height - UI.StatusBarHeight) {
		Corner2.y = UI.height - UI.StatusBarHeight - 2;
		Corner1.y -= 2;
		Corner3.y -= 2;
	}
	if (Corner3.y > UI.height - UI.StatusBarHeight) {
		Corner3.y = UI.height - UI.StatusBarHeight - 2;
		Corner2.y -= 2;
		Corner1.y -= 2;
	}
	// the following validation will be used for the copy / paste operation 
	if (Corner1.x > Corner2.x && Corner1.x > Corner3.x) {
		if (Corner1.x > UI.width) {
			int x = Corner1.x - UI.width-60;
			Corner1.x = UI.width - 60;
			Corner2.x -= x;
			Corner3.x -= x;
		}
	}
	else if (Corner2.x > Corner1.x && Corner2.x > Corner3.x) {
		if (Corner2.x > UI.width) {
			int x = Corner2.x - UI.width - 60;
			Corner2.x = UI.width - 60;
			Corner1.x -= x;
			Corner3.x -= x;
		}
	}
	else if (Corner3.x > Corner1.x && Corner3.x > Corner2.x) {
		if (Corner3.x > UI.width) {
			int x = Corner3.x - UI.width - 60;
			Corner3.x = UI.width - 60;
			Corner2.x -= x;
			Corner1.x -= x;
		}
	}


}

CTriangle::CTriangle(CFigure* temp) : CFigure(temp->getGfx(), temp->getcenter(), temp->getcorner1(), temp->getcorner2(), temp->getcorner3()) {
	// these if statements are used to chekc that the points are whithin boundries
	shapetype = 't';

	if (Corner1.y < UI.LineUnderTBWidth + UI.ToolBarHeight) {
		Corner1.y = UI.LineUnderTBWidth + UI.ToolBarHeight + 2;
		Corner2.y += UI.LineUnderTBWidth + UI.ToolBarHeight + 2;
		Corner3.y += UI.LineUnderTBWidth + UI.ToolBarHeight + 2;
	}
	if (Corner2.y < UI.LineUnderTBWidth + UI.ToolBarHeight) {
		Corner2.y = UI.LineUnderTBWidth + UI.ToolBarHeight + 2;
		Corner3.y += UI.LineUnderTBWidth + UI.ToolBarHeight + 2;
		Corner1.y += UI.LineUnderTBWidth + UI.ToolBarHeight + 2;
	}

	if (Corner3.y < UI.LineUnderTBWidth + UI.ToolBarHeight) {
		Corner3.y = UI.LineUnderTBWidth + UI.ToolBarHeight + 2;
		Corner2.y += UI.LineUnderTBWidth + UI.ToolBarHeight + 2;
		Corner1.y += UI.LineUnderTBWidth + UI.ToolBarHeight + 2;
	}

	if (Corner1.y > UI.height - UI.StatusBarHeight) {
		Corner1.y = UI.height - UI.StatusBarHeight - 2;
		Corner2.y -= 2;
		Corner3.y -= 2;
	}
	if (Corner2.y > UI.height - UI.StatusBarHeight) {
		Corner2.y = UI.height - UI.StatusBarHeight - 2;
		Corner1.y -= 2;
		Corner3.y -= 2;
	}
	if (Corner3.y > UI.height - UI.StatusBarHeight) {
		Corner3.y = UI.height - UI.StatusBarHeight - 2;
		Corner2.y -= 2;
		Corner1.y -= 2;
	}
	// the following validation will be used for the copy / paste operation 
	if (Corner1.x > Corner2.x && Corner1.x > Corner3.x) {
		if (Corner1.x > UI.width) {
			int x = Corner1.x - UI.width - 20;
			Corner1.x = UI.width - 20;
			Corner2.x -= x;
			Corner3.x -= x;
		}
	}
	else if (Corner2.x > Corner1.x && Corner2.x > Corner3.x) {
		if (Corner2.x > UI.width) {
			int x = Corner2.x - UI.width - 20;
			Corner2.x = UI.width - 20;
			Corner1.x -= x;
			Corner3.x -= x;
		}
	}
	else if (Corner3.x > Corner1.x && Corner3.x > Corner2.x) {
		if (Corner3.x > UI.width) {
			int x = Corner3.x - UI.width - 20;
			Corner3.x = UI.width - 20;
			Corner2.x -= x;
			Corner1.x -= x;
		}
	}


}
CTriangle::CTriangle() {
	shapetype = 't';
}
void CTriangle::Draw(Output* pOut) const
{
	pOut->DrawTri(Corner1, Corner2, Corner3, FigGfxInfo, Selected);
}
bool CTriangle::Search(int x, int y) {
	Point P;
	P.x = x;
	P.y = y;
	return TriChecker(Corner1, Corner2, Corner3, P);
	
}
void CTriangle::PrintInfo(Output* pOut) {
	
	string id = to_string(ID);
	string area = to_string(int(triarea(Corner1,Corner2,Corner3)));
	string height = to_string(abs(Corner1.y - Corner2.y));
	string bc = Color2string(Brdrcolor);
	string fc = Color2string(Fillcolor);

	pOut->PrintMessage("Triangle ID: " + id + "    Area: " + area + "    Border Color: " + bc + "    Fill Color: " + fc);
}

void CTriangle::Save(ofstream& savefile) {

	savefile << shapetype << " " << ID << " " << Corner1.x << " " << Corner1.y << " " << Corner2.x << " " << Corner2.y << " " <<Corner3.x<<" " << Corner3.y<< " " << Color2string(Brdrcolor) << " " << Color2string(Fillcolor) << endl;
}
void CTriangle::Load(ifstream&savefile) {
	string d, f;
	savefile >> ID >> Corner1.x >> Corner1.y >>Corner2.x>>Corner2.y>>Corner3.x>>Corner3.y>> d >> f;
	ChngDrawClr(String2color(d));
	ChngFillClr(String2color(f));

}