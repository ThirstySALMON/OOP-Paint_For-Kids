#ifndef CFIGURE_H
#define CFIGURE_H
#pragma once
#include "..\defs.h"
#include "..\GUI\Output.h"
#include <math.h>
#include<iostream>
#include<fstream>

//Base class for all figures
class CFigure
{
protected:
	int ID;		//Each figure has an ID
	bool Selected;	//true if the figure is selected.
	bool cut; //true if figure is cut 
	char shapetype;
	bool isfilled;
	GfxInfo FigGfxInfo;	//Figure graphis info
	color Fillcolor; // to keep track of the figure's  fill color through changes 
	color Brdrcolor;
	Point Center;  // these points will be needed for copy / pasting function
	Point Corner1;
	Point Corner2;
	Point Corner3;
	
	/// Add more parameters if needed.

public:
	CFigure(GfxInfo FigureGfxInfo , Point , Point , Point , Point);
	CFigure();
	void SetSelected(bool s);	//select/unselect the figure
	bool IsSelected() const;	//check whether fig is selected
	void SetID(int id); // Set ID for  figure
	int GetID() const; // Gets ID fo figure , this is needed to check that no figures have the same ID
	color getclr(bool c) const; // returns bordor or fill color based on a true or false value 
	char gettype() const;
	bool getCut() const; // checks if a figure is cut or not
	void setCut(bool); // sets a figure to cut or not 
	void ChngDrawClr(color Dclr);	//changes the figure's drawing color
	void ChngFillClr(color Fclr);	//changes the figure's filling color
	double triarea(Point P1, Point P2, Point P3);
	bool  TriChecker(Point P1, Point P2, Point P3, Point P4);
	Point getcenter(); // these series of setters and getter will be used exclusivly by the copy and paste class
	Point getcorner1();
	Point getcorner2();
	Point getcorner3();
	void setcenter(Point);
	void setcorner1(Point);
	void setcorner2(Point);
	void setcorner3(Point);
	GfxInfo getGfx();
	string Color2string(color);
	color String2color(string);
	///The following functions should be supported by the figure class
	///It should be overridden by each inherited figure

	///Decide the parameters that you should pass to each function	

	virtual bool Search(int x, int y) = 0; // Function where all figures will have different logic for selection 
	virtual void Draw(Output* pOut) const = 0;		//Draw the figure
	virtual void PrintInfo(Output* pOut) = 0;	//print all figure info on the status bar
	virtual void Save(ofstream &OutFile) = 0;	//Save the figure parameters to the file
	virtual void Load(ifstream &Infile) = 0;	//Load the figure parameters to the file
};

#endif