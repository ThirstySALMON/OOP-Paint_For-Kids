#pragma once


#include "CFigure.h"

class CTriangle : public CFigure
{
private:
	
public:
	CTriangle(Point ,Point, Point , GfxInfo FigureGfxInfo);
	CTriangle(CFigure* temp);
	CTriangle();
	virtual void Draw(Output* pOut) const;
	bool Search(int x, int y);
	virtual void PrintInfo(Output* pOut);
	virtual void Save(ofstream&);
	virtual void Load(ifstream&);
};


