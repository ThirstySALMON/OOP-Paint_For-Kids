#ifndef CRECT_H
#define CRECT_H

#include "CFigure.h"

class CRectangle : public CFigure
{
private:

public:
	CRectangle(Point , Point, GfxInfo FigureGfxInfo );
	CRectangle(CFigure*);
	CRectangle();
	virtual void Draw(Output* pOut) const;//the reason for implementation is explained there
	bool Search(int x , int y) ;
	virtual void PrintInfo(Output* pOut); 
	virtual void Save(ofstream&);
	virtual void Load(ifstream&);

};

#endif