#include "CSquare.h"

CSquare::CSquare(Point center, GfxInfo FigureGfxInfo) :CFigure(FigureGfxInfo, center , center , center , center)
{


    shapetype = 's';
    if (Center.x - 50 < 0) {
        Center.x = 55;

   }
    if (Center.x + 50 > UI.width - 50) {
        Center.x = UI.width - 50 - 20;
    }
    if (Center.y-50 < UI.LineUnderTBWidth + UI.ToolBarHeight) {
        Center.y = UI.LineUnderTBWidth + UI.ToolBarHeight + 55;
    }
    if (Center.y + 50 > UI.height - UI.StatusBarHeight) {
        Center.y = UI.height - UI.StatusBarHeight - 55;

    }
}
CSquare::CSquare(CFigure* temp) : CFigure(temp->getGfx(), temp->getcenter(), temp->getcenter(), temp->getcenter(), temp->getcenter()) {
    shapetype = 's';
    

    if (Center.x - 50 < 0) {
        Center.x = 55;

    }
    if (Center.x + 50 > UI.width - 50) {
        Center.x = UI.width - 50 - 20;
    }
    if (Center.y - 50 < UI.LineUnderTBWidth + UI.ToolBarHeight) {
        Center.y = UI.LineUnderTBWidth + UI.ToolBarHeight + 55;
    }
    if (Center.y + 50 > UI.height - UI.StatusBarHeight) {
        Center.y = UI.height - UI.StatusBarHeight - 55;

    }
}


void CSquare::Draw(Output* pOut) const
{
    pOut->DrawSquare(Center, FigGfxInfo, Selected);
}
CSquare::CSquare() {
    shapetype = 's';
}
bool CSquare:: Search(int x, int y) {

    Point Corn1, Corn2;// Declare two extra points to be used for searching 
    int half_length = 50; // Half length of square side which was set in output.cpp
    Corn1.x = Center.x-50;
    Corn1.y = Center.y-50;
    Corn2.x = Center.x+50;
    Corn2.y = Center.y+50;

    if (x > Corn1.x && x<Corn2.x && y>Corn1.y && y < Corn2.y) {
        return true;
    }
    return false;
}

void CSquare::PrintInfo(Output* pOut) 
{
    string id = to_string(ID);

    string bc = Color2string(Brdrcolor);
    string fc = Color2string(Fillcolor);

    pOut->PrintMessage("Square ID: " + id + "    Border Color: " + bc + "    Fill Color: " + fc);
}
void CSquare::Save(ofstream& savefile) {

    savefile << shapetype << " " << ID << " " << Center.x << " " << Center.y << " " << Color2string(Brdrcolor) << " " << Color2string(Fillcolor) << endl;
}
void CSquare::Load(ifstream&savefile) {
    string d, f;
    savefile >> ID >> Center.x >> Center.y >> d >> f;
    ChngDrawClr( String2color(d));
    ChngFillClr(String2color(f));
}