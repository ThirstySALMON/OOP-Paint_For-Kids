#include "CFigure.h"
#pragma once
CFigure::CFigure(GfxInfo FigureGfxInfo , Point cent , Point cor1 , Point cor2 , Point cor3)
{ 
	srand(time(0));
	FigGfxInfo = FigureGfxInfo;	//Default status is non-filled.
	Selected = false;
	cut = false;
	isfilled = FigureGfxInfo.isFilled;
	Brdrcolor= FigureGfxInfo.DrawClr;
	Fillcolor = FigureGfxInfo.FillClr;
	Center = cent;   // All points are moved up here so copy constructor could work
	Corner1 = cor1;
	Corner2 = cor2;
	Corner3 = cor3;
}
CFigure::CFigure() {
	Selected = false;
	cut = false;
}
char CFigure::gettype() const {
	return shapetype;
}
void CFigure::SetSelected(bool s) 
{	Selected = s;}

bool CFigure::IsSelected() const
{	return Selected; }

void CFigure::SetID(int id) {
	ID = id;
}

int CFigure::GetID() const {
	return ID;
}
color CFigure::getclr(bool c)const {
	if (c) { return Brdrcolor; }
	else { return Fillcolor; }
}
bool CFigure::getCut() const {
	return cut;
}
void CFigure::setCut(bool cut) {
	if (cut) {
		FigGfxInfo.DrawClr = GRAY;
		FigGfxInfo.FillClr = GRAY;
		FigGfxInfo.isFilled = true;
		SetSelected(false);
		this->cut = true;
		return;
	}
	
		FigGfxInfo.DrawClr = Brdrcolor;
		FigGfxInfo.FillClr = Fillcolor;
		FigGfxInfo.isFilled = isfilled;
		this->cut = false;
	
}
void CFigure::ChngDrawClr(color Dclr)
{	FigGfxInfo.DrawClr = Dclr;
	Brdrcolor = Dclr; 
}

void CFigure::ChngFillClr(color Fclr)
{
	if (Fclr != WHITE) {
		FigGfxInfo.isFilled = true;
		FigGfxInfo.FillClr = Fclr;
		Fillcolor = Fclr;
		isfilled = true;
	}
	else {
		FigGfxInfo.isFilled = false;
		FigGfxInfo.FillClr = Fclr;
		Fillcolor = Fclr;
		isfilled = false;

	}
}
double CFigure::triarea(Point P1, Point P2, Point P3) {
	return abs(P1.x * (P2.y - P3.y) + P2.x * (P3.y - P1.y) + P3.x * (P1.y - P2.y)) / 2; 
}


bool CFigure:: TriChecker(Point P1 , Point P2 , Point P3 , Point P4)// this function is used to get if a point is present in a triangle 
		//the reason it is here because it will be used by both the Ctriangle and Chexagon class
{	
	double A, t1, t2, t3;
	A = triarea(P1, P2, P3);
	t1 = triarea(P1, P2, P4);
	t2 = triarea(P1, P4, P3);
	t3 = triarea(P4, P2, P3);
	if (5>abs(A -  (t1 + t2 + t3))) {
		return true;
	}
	return false;

}

Point CFigure::getcenter()
{
	return Center;
}

Point CFigure::getcorner1()
{
	return Corner1;
}

Point CFigure::getcorner2()
{
	return Corner2;
}
Point CFigure::getcorner3()
{
	return Corner3;
}

void CFigure::setcenter(Point cent)
{
	 Center= cent;
}
void CFigure::setcorner1(Point cor1)
{
	 Corner1=cor1;
}
void CFigure::setcorner2(Point cor2)
{
	 Corner2= cor2;
}
void CFigure::setcorner3(Point cor3)
{
	 Corner3= cor3;
}
GfxInfo CFigure::getGfx() {
	return FigGfxInfo;
}
string CFigure:: Color2string(color col) {
	if (col == RED) {
		return "Red";
	}
	else if (col == GREEN) {
		return "Green";
	}
	else if (col == BLUE)
		return "Blue";
	else if (col == YELLOW)
		return "Yellow";
	else if (col == ORANGE)
		return "Orange";
	else if (col == BLACK)
		return "Black";
	else
		return "No_Fill";

}

color CFigure::String2color(string str)
{
	if (str == "Red") {
		return RED;
	}
	else if (str == "Green") {
		return GREEN;
	}
	else if (str == "Blue")
		return BLUE;
	else if (str == "Yellow")
		return YELLOW;
	else if (str == "Orange")
		return ORANGE;
	else if (str == "Black")
		return BLACK;
	else if (str == "No_Fill")
		return WHITE;
	
}
