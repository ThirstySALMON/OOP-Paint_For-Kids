#include "CRectangle.h"
#include"math.h"
using namespace std;

CRectangle::CRectangle(Point P1, Point P2, GfxInfo FigureGfxInfo):CFigure(FigureGfxInfo , P1 ,P1 , P2 ,P1)
{


	shapetype = 'r';
	int length = abs(Corner1.x - Corner2.x);
	int height = abs((Corner1.y - Corner2.y));

	                  // next few blocks is to make sure that the rectangle is whithin bounds 
	if (Corner1.y < Corner2.y) {
		if (Corner1.y < UI.ToolBarHeight + UI.LineUnderTBWidth) {
			Corner1.y = 5 + UI.ToolBarHeight + UI.LineUnderTBWidth;
			Corner2.y = Corner1.y + height; // to maintain the size of the rectangle
		}
	}
	else {
		if (Corner2.y < UI.ToolBarHeight + UI.LineUnderTBWidth) {
			Corner2.y = 5 + UI.ToolBarHeight + UI.LineUnderTBWidth;
			Corner1.y = Corner2.y+height; // to maintain the size of the rectangle
		}
	}
	if (Corner2.y > Corner1.y) {
		if (Corner2.y > UI.height - UI.StatusBarHeight) {
			Corner2.y = UI.height - UI.StatusBarHeight - 5;
			Corner1.y = Corner2.y - height;
		}
	}
	else {
		if (Corner1.y > UI.height - UI.StatusBarHeight) {
			Corner1.y = UI.height - UI.StatusBarHeight - 5;
			Corner2.y = Corner1.y - height;
		}
	}
	        // The next validation is done for copy / pasting since the program won't know if the triangle is of out of bounds or not 
	
	if (Corner2.x > Corner1.x) {
		if (Corner2.x > UI.width - length) {
			Corner2.x = UI.width - 20;
			Corner1.x = Corner2.x- length;
		}
	}
	else {
		if (Corner1.x > UI.width - length) {
			Corner1.x = UI.width - 20;
			Corner2.x = Corner1.x - length;
		}
	}

}
CRectangle::CRectangle(CFigure* temp) : CFigure(temp->getGfx(), temp->getcenter(), temp->getcorner1(), temp->getcorner2(), temp->getcorner3()) {
	shapetype = 'r';
	int length = abs(Corner1.x - Corner2.x);
	int height = abs((Corner1.y - Corner2.y));
	

	// next few blocks is to make sure that the rectangle is whithin bounds 
	if (Corner1.y < Corner2.y) {
		if (Corner1.y < UI.ToolBarHeight + UI.LineUnderTBWidth) {
			Corner1.y = 5 + UI.ToolBarHeight + UI.LineUnderTBWidth;
			Corner2.y = Corner1.y + height; // to maintain the size of the rectangle
		}
	}
	else {
		if (Corner2.y < UI.ToolBarHeight + UI.LineUnderTBWidth) {
			Corner2.y = 5 + UI.ToolBarHeight + UI.LineUnderTBWidth;
			Corner1.y = Corner2.y + height; // to maintain the size of the rectangle
		}
	}
	if (Corner2.y > Corner1.y) {
		if (Corner2.y > UI.height - UI.StatusBarHeight) {
			Corner2.y = UI.height - UI.StatusBarHeight - 5;
			Corner1.y = Corner2.y - height;
		}
	}
	else {
		if (Corner1.y > UI.height - UI.StatusBarHeight) {
			Corner1.y = UI.height - UI.StatusBarHeight - 5;
			Corner2.y = Corner1.y - height;
		}
	}
	// The next validation is done for copy / pasting since the program won't know if the triangle is of out of bounds or not 

	if (Corner2.x > Corner1.x) {
		if (Corner2.x > UI.width - length) {
			Corner2.x = UI.width - 20;
			Corner1.x = Corner2.x - length;
		}
	}
	else {
		if (Corner1.x > UI.width - length) {
			Corner1.x = UI.width - 20;
			Corner2.x = Corner1.x - length;
		}
	}

}
CRectangle::CRectangle() { shapetype = 'r';
}
	

void CRectangle::Draw(Output* pOut) const
{
	//Call Output::DrawRect to draw a rectangle on the screen	
	pOut->DrawRect(Corner1, Corner2, FigGfxInfo, Selected);
}
bool CRectangle::Search(int x, int y)  {
	
	if (Corner1.x < Corner2.x && Corner1.y < Corner2.y) {
		if (x > Corner1.x && x<Corner2.x && y>Corner1.y && y < Corner2.y) {
			return true; 
		}
	}
	else if (Corner1.x < Corner2.x && Corner1.y > Corner2.y) {
		if (x >Corner1.x && x<Corner2.x && y<Corner1.y && y > Corner2.y) {
			return true;
		}
	}
	else if (Corner1.x > Corner2.x && Corner1.y > Corner2.y) {
		if (x <Corner1.x && x>Corner2.x && y<Corner1.y && y >Corner2.y) {
			return true;
		}
	}
	else if (Corner1.x > Corner2.x && Corner1.y <Corner2.y) {
		if (x < Corner1.x && x > Corner2.x && y>Corner1.y && y <Corner2.y) {
			return true;
		}
	}
 
	return false;
}
void CRectangle::PrintInfo(Output* pOut) {
	string id = to_string(ID);
	string width = to_string(abs(Corner1.x - Corner2.x));
	string height = to_string(abs(Corner1.y - Corner2.y));
	string bc = Color2string(Brdrcolor);
	string fc = Color2string(Fillcolor);
	
	pOut->PrintMessage("Rectangle ID: " + id + "    Width: "+width+ "    Height: "+height + "    Border Color: " + bc + "    Fill Color: " + fc);
}

void CRectangle::Save(ofstream&savefile) {
	
	savefile << shapetype<<" "<<ID<<" "<<Corner1.x<<" " << Corner1.y<<" " << Corner2.x << " " << Corner2.y<<" "<<Color2string(Brdrcolor)<<" "<<Color2string(Fillcolor)<<endl;
}
void CRectangle::Load(ifstream& savefile) {
	string d, f;
	savefile >> ID >> Corner1.x >> Corner1.y>>Corner2.x>>Corner2.y >> d >> f;
	ChngDrawClr(String2color(d));
	ChngFillClr(String2color(f));
}