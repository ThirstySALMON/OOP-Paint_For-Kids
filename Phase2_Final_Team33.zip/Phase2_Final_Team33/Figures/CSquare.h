#pragma once
#ifndef CSQUARE_H
#define CSQUARE_H

#include "CFigure.h"

class CSquare : public CFigure
{	
public:
	CSquare(Point Center, GfxInfo FigureGfxInfo);
	CSquare(CFigure*);
	CSquare();
	virtual void Draw(Output* pOut) const;
	virtual void PrintInfo(Output* pOut) ;
	virtual bool Search(int x, int y);
	virtual void Save(ofstream&);
	virtual void Load(ifstream&);

};

#endif
