#include "CCircle.h"
#include<iostream>
CCircle::CCircle(Point P1, Point P2, GfxInfo FigureGfxInfo) :CFigure(FigureGfxInfo , P1 , P2 , P2 , P2)
{   // The following blocks of code is to make sure that the drawn circle is within bounds
	shapetype = 'c';

    int radius = sqrt(((Corner1.x - Center.x) * (Corner1.x - Center.x)) + ((Corner1.y - Center.y) * (Corner1.y - Center.y)));
    Corner1.x = Center.x;
    Corner1.y = Center.y + radius;
	if (2*radius > 498) {
		radius = 245;
		Corner1.y = radius + Center.y;
	}
	if (Center.y < 52) {
		Center.y = 52 + radius + 5;
	}
	if (Center.y > 550) {
		Center.y = 595 - radius;
	}
	if (Center.y - radius < 52) {
		Center.y = 52 + radius + 5;
	}
	if (Center.y + radius > 550) {
		Center.y = 595 - radius;

	}
	
	if (Center.x - radius < 0) {
		Center.x = radius + 5;
	}
	if (UI.width- radius < Center.x) {
		Center.x = UI.width - 20 - radius;
	}
	
	Corner1.x = Center.x;
	Corner1.y = Center.y + radius;
}
CCircle::CCircle(CFigure* temp) : CFigure(temp->getGfx(), temp->getcenter(), temp->getcorner1(), temp->getcorner2(), temp->getcorner3()) {
	shapetype = 'c';

	int radius = sqrt(((Corner1.x - Center.x) * (Corner1.x - Center.x)) + ((Corner1.y - Center.y) * (Corner1.y - Center.y)));
	Corner1.x = Center.x;
	Corner1.y = Center.y + radius;
	if (2 * radius > 498) {
		radius = 245;
		Corner1.y = radius + Center.y;
	}
	if (Center.y < 52) {
		Center.y = 52 + radius + 5;
	}
	if (Center.y > 550) {
		Center.y = 595 - radius;
	}
	if (Center.y - radius < 52) {
		Center.y = 52 + radius + 5;
	}
	if (Center.y + radius > 550) {
		Center.y = 595 - radius;

	}

	if (Center.x - radius < 0) {
		Center.x = radius + 5;
	}
	if (UI.width - radius < Center.x) {
		Center.x = UI.width - 20 - radius;
	}

	Corner1.x = Center.x;
	Corner1.y = Center.y + radius;
}
CCircle::CCircle() { shapetype = 'c';
}
void CCircle::Draw(Output* pOut) const
{

    pOut->Drawc(Center, Corner1, FigGfxInfo, Selected);
}
void CCircle::PrintInfo(Output* pOut)
{
	string id = to_string(ID);
	string radius = to_string(abs(Corner1.y - Center.y));
	string bc = Color2string(Brdrcolor);
	string fc = Color2string(Fillcolor);

	pOut->PrintMessage("Circle ID: " + id + "    Radius: " + radius + "    Border Color: " + bc + "    Fill Color: " + fc);

}
bool CCircle::Search(int x, int y) {
    int distance = sqrt(((x - Center.x) * (x - Center.x)) + ((y - Center.y) * (y - Center.y))); // distance between point and center
    int radius = sqrt(((Corner1.x - Center.x) * (Corner1.x - Center.x)) + ((Corner1.y - Center.y) * (Corner1.y - Center.y)));
    if (radius >= distance) {
        return true;
    }
    return false;
}
void CCircle::Save(ofstream& savefile) {

	savefile << shapetype << " " << ID << " " << Center.x << " " << Center.y <<" " << Corner1.x << " " << Corner1.y << " " << Color2string(Brdrcolor) << " " << Color2string(Fillcolor) << endl;
}
void CCircle::Load(ifstream&savefile) {
	string d, f;
	savefile >> ID >> Center.x >> Center.y >>Corner1.x>>Corner1.y>> d >> f;
	ChngDrawClr(String2color(d));
	ChngFillClr(String2color(f));
}