#pragma once
#ifndef CCIRCLE_H
#define CCIRCLE_H
#include "CFigure.h"
class CCircle : public CFigure
{
private:
	
public:
	CCircle(Point, Point, GfxInfo FigureGfxInfo);
	CCircle(CFigure*);
	CCircle();
	virtual void Draw(Output* pOut) const;
	bool Search(int x, int y);
	virtual void PrintInfo(Output* pOut);
	virtual void Save(ofstream&);
	virtual void Load(ifstream&);

};

#endif




